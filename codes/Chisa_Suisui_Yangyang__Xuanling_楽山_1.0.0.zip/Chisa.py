import time

from src.char.BaseChar import CharType, SwitchPriority, get_default_buff_time
from src.char.Chisa import Chisa as NativeChisa


class Chisa(NativeChisa):
    """千咲。她现在同时出现在两条队伍轴里, do_perform 按队伍分流:

      1) 爱达千(爱弥斯/达尼娅/千咲) —— 【轴的入口是她】。整条轴(启动 + 循环)是一条
         跨三人的线性宏, 住在 Denia.py 里(自定义角色文件互相 import 不到, 只能靠
         task.chars 拿到彼此的实例)。这里只负责把启动轴踢起来, 见 denia_macro()。
         千咲在 CharFactory 里登记的是 HEALER, 所以 AutoCombatTask.run() 开头那次
         switch_healer() 正好会把她摆上场 —— 跟这条轴的入口是一致的, 不用关掉它。

      2) 穗千秧(穗穗/千咲/秧秧玄翎) —— 下面那条 do_team_axis, 原样保留。

    【继承的是原版 src.char.Chisa, 不是 BaseChar】(2026-08-16 改): 原来这个文件是
    8-03 的一份过期拷贝, 连 do_dps_perform / perform_forte 都是照抄的 —— 上游后来
    改了就吃不到, 而且兜底的 super().do_perform() 会掉进 BaseChar 那套通用轮换。
    下面那两个同名方法留着不删(值可能被调过), 想吃上游版本直接删掉即可。

    ================= 穗千秧的轴 (do_team_axis) =================
        Q → E → A(2.6s) → R → 强化E → 一直 a 到能量条消失(3.5s) → 切秧秧
        (R 之后的 F 处决试过, 会吞掉强化E, 已用 F_BREAK_ON_LIB 关掉)

    原来的 do_fast_support() 还留在下面: 那是"进场就走"的极速辅助版, 穗千秧不用它,
    因为这里要千咲实打实站几秒把 R 和强化E 打出来。想换回去改 do_perform() 一行。
    Chisa DPS 配置项还在, 勾上就还是走原来的主C轴。
    """

    # ================================================================ 固定顺序切人 (公共段)
    # 这一段在 Suisui.py / Chisa.py / YangYangSp.py 三个文件里逐字一样, 改一处记得同步改三处。
    # 下面各自的常量写在这一段【之后】, 所以子类想覆盖哪个直接在下面重写就行。
    #
    # 为什么不用框架的 switch_next_char():
    #   1. 它按 get_switch_priority() 现场挑人, 顺序会漂 —— 这套轴要求死顺序;
    #   2. 它内部有三处补普攻 ("performing too fast add a normal attack"、维持锁定、
    #      切换未检测到时补点击), 打完最后一下想立刻走人时那几下 A 会把节奏拖乱。
    # 代价是框架的交接记账要自己补, 全在 handoff_to() 里。

    SWITCH_TIMEOUT: float = 2.0        # 单程切人的最长尝试时间 (秒)
    SWITCH_KEY_INTERVAL: float = 0.12  # 连按数字键的间隔 (秒)
    # 切到之后等角色站稳的时间 (秒)。很敏感 —— 实测 0.50 / 0.52 会让下一个角色的起手被吞,
    # 0.55 才稳, 别再往下压
    SWITCH_SETTLE: float = 0.55
    SETTLE_ATTACK_INTERVAL: float = 0.42
    HANDOFF_CON_WAIT: float = 0.8      # 交接时等协奏读数稳定的上限 (秒)
    HANDOFF_CON_POLL: float = 0.1
    HOLD_POLL: float = 0.1             # 长按期间轮询条件的间隔 (秒)
    # 切走前按 F 处决 —— 框架 switch_next_char() 里有 current_char.f_break(True), 直接
    # 按数字键切人会绕开它。这套轴里默认【关掉】: handoff_to() 是在 switch_to_index()
    # 之后调的, 那时候下一个角色已经站上场了, 这一下 F 会被他吃掉, 而且发生在他的 R
    # 之前 (千咲"还没按 R 就开处决"就是这么来的)。处决统一由千咲在 R 之后接
    F_BREAK_ON_HANDOFF: bool = False

    # 别人用 handoff_to() 直接切给我时打的标记, 写成类属性省掉 __init__。
    # 不能只靠 has_intro —— reset_state() 每次重读队伍都会把它清成 False, 而战斗判定
    # 一抖动就会重进战斗、重读队伍, 于是角色以为自己空手入场, 跑去走开场那套流程
    intro_pending = False
    # 切人【真正完成】那一刻的时间戳 —— in_team 认出换人成功的那一帧, 不是
    # settle_with_attack 站稳之后。循环轴的落地E 就按这个锚点计时, 差 0.55 秒
    # 就会掉进"E 按在下落段完全没反应"的失败区
    switch_confirmed_at = 0.0

    def note_intro_handoff(self):
        """被别人用直接切人的方式交接进场时调用 —— 记下"我是带着变奏上来的"。"""
        self.intro_pending = True

    def take_intro(self):
        """本次入场是否带着变奏。读完就清, 避免下一轮误判。"""
        intro = self.has_intro or self.intro_pending
        self.intro_pending = False
        return intro

    def reset_fixed_rotation(self):
        """战斗结束时调 —— 在各自的 on_combat_end() 里。"""
        self.intro_pending = False

    def direct_switch(self, slot=None, assume_intro=False):
        """按数字键直接切到指定队伍位置 (1-based), 并自己补上框架的交接记账。

        Args:
            slot: 不传就用 NEXT_SLOT。
            assume_intro: True 时不读协奏, 直接认定是满的。刚放完大招要用这个 ——
                能量环读数滞后会把 has_intro 误判成 False, 下一个角色就拿不到变奏增益。
        """
        slot = self.NEXT_SLOT if slot is None else slot
        if slot is None:
            return False
        target = self.char_at_slot(slot)
        if target is None or target is self:
            return False

        has_intro = True if assume_intro else self.wait_con_full()
        if not self.switch_to_index(target.index):
            self.logger.warning(f'direct switch to slot {slot} failed')
            return False
        self.logger.info(f'direct switched to slot {slot} ({target.char_name}, intro={has_intro})')
        self.handoff_to(target, has_intro)
        return True

    def switch_to_index(self, index):
        """按数字键切到指定队伍位置, 直到 in_team 确认切过去了。

        点击落在谁身上就由谁打出来, 所以等待期间也保持点普攻, 两边连段都不断档。
        """
        start = time.time()
        while time.time() - start < self.SWITCH_TIMEOUT:
            in_team, current_index, _ = self.task.in_team()
            if in_team and current_index == index:
                # 【先记时间戳再站稳】: settle_with_attack 要花 SWITCH_SETTLE 秒,
                # 记在它后面的话锚点整体晚 0.55 秒, 靠锚点计时的动作全跟着晚
                self.switch_confirmed_at = time.time()
                self.settle_with_attack(self.SWITCH_SETTLE)
                return True
            self.task.send_key(index + 1)
            self.click()
            self.sleep(self.SWITCH_KEY_INTERVAL, check_combat=False)
        return False

    def settle_with_attack(self, duration):
        """等 duration 秒, 期间保持点普攻, 不干等。"""
        end = time.time() + duration
        while time.time() < end:
            self.click()
            self.sleep(min(self.SETTLE_ATTACK_INTERVAL, max(0.0, end - time.time())),
                       check_combat=False)

    def handoff_to(self, target, has_intro):
        """把场上角色交接给 target —— 复刻 switch_next_char() 内部那套记账。

        直接按数字键切人绕开了框架的交接逻辑, 必须自己补上, 否则:
          - 没人的 is_current_char 是 True → get_current_char() 返回 None → 下一帧崩溃;
          - has_intro / last_outro_time 不更新, 下一个角色拿不到变奏。
        """
        if self.F_BREAK_ON_HANDOFF:
            self.f_break(check_f_on_switch=True)
        self.task.in_liberation = False
        self.switch_out(con_full=has_intro)
        target.is_current_char = True
        target.has_intro = has_intro
        if has_intro and hasattr(target, 'note_intro_handoff'):
            # has_intro 是易失的, 再给对方补一个它自己保管的持久标记
            target.note_intro_handoff()
        # 用 in_team 确认那一刻, 不是现在 —— 中间隔着 settle_with_attack 那 0.55 秒
        target.last_switch_in_time = self.switch_confirmed_at or time.time()
        self.switch_confirmed_at = 0.0
        if has_intro:
            now = time.time()
            self.task.add_freeze_duration(now, target.intro_motion_freeze_duration, -100)
            self.last_outro_time = now

    def wait_con_full(self):
        """短暂轮询协奏是否满 —— 用来决定交接时给不给对方变奏。

        不能只读一次: 打完最后一下那一刻协奏其实已经满了, 但能量环读数滞后。
        必须在【按切人键之前】读: 切走之后能量环显示的已经是新角色的了。
        """
        start = time.time()
        while time.time() - start < self.HANDOFF_CON_WAIT:
            if self.is_con_full():
                return True
            self.sleep(self.HANDOFF_CON_POLL, check_combat=False)
        self.logger.info(f'con not full before switch (con={self.get_current_con()}), '
                         f'next char gets no intro')
        return False

    def char_at_slot(self, slot):
        """按队伍位置 (1-based) 取角色, 越界返回 None。"""
        index = slot - 1
        for char in self.task.chars:
            if char is not None and char.index == index:
                return char
        return None

    def attack_chain(self, count, interval, last_interval=None):
        """点按普攻打一轮连段。

        Args:
            last_interval: 最后一段之后的间隔。后面紧接切人时传更小的值 —— 按下切人键之后
                还要等游戏识别切换完成, 那段时间最后一下的动作照样在演, 两者是重叠的。
        """
        for i in range(count):
            self.click()
            if i == count - 1 and last_interval is not None:
                self.sleep(last_interval)
            else:
                self.sleep(interval)

    def hold_until(self, cond, timeout, name):
        """轮询某个条件, 期间不动手 —— 攻击键的按下/松开由调用方管。"""
        start = time.time()
        while self.time_elapsed_accounting_for_freeze(start) < timeout:
            if cond():
                self.logger.info(f'{name} ready after '
                                 f'{self.time_elapsed_accounting_for_freeze(start):.1f}s')
                return True
            self.sleep(self.HOLD_POLL)
        self.logger.info(f'timed out waiting for {name} ({timeout:.1f}s)')
        return False


    # ---------------------------------------------- "没打到就不许切人" 的硬 gate
    # 这套轴是靠变奏/延奏一棒接一棒串起来的: 任何一棒少做一步, 代价都直接传给下一棒。
    # 实测 21:23 那一圈就是完整的传染链:
    #   穗穗 forte3 没读到 -> 硬走 Q/R -> "liberation not ready, leaving without field"
    #   -> 领域没放, 千咲上场 -> "chisa: liberation not ready" -> 整圈裸打。
    # 所以关键步骤不再"到点就走", 改成留场重试到真打出来为止。
    #
    # 【没有超时是有意的】: 给上限就等于"打不出来也走", 那这个 gate 等于没有。
    # 唯一的出口是 check_combat() —— 脱战/任务被停时它抛异常, 整条轴一起退出。
    # 怪都没了的话, "这一步没打到"本来也就不是问题了。
    GATE_POLL: float = 0.12       # gate 轮询间隔 (秒)
    GATE_LOG_EVERY: float = 3.0   # 卡住时每隔这么久打一条日志, 好在日志里一眼看出卡在哪

    def require(self, name, cond, action=None, timeout=0):
        """留场直到 cond() 成立 —— 这一步没做到就不许往下走。

        Args:
            name: 打日志用的步骤名, 卡住时就是靠它定位。
            cond: 判据, 返回真就放行。
            action: 每轮做的事, 一般传 self.click。不传就是干等 (长按期间要用这个,
                手上已经按着了, 再 click 会打断长按)。
            timeout: >0 时的上限 (秒), 到点放行并返回 False。默认 0 = 不设上限。
                【什么时候该给上限】: 这一步做不到时"照走"能自愈的, 就必须给 ——
                比如协奏没满只是让下一棒退回启动轴(那条轴本来就为空手入场准备),
                而卡死在这里不能自愈。实测 01:18 那轮 fill_con 无上限直接把任务挂住了。

        Returns:
            bool: 条件成立返回 True; 到 timeout 放弃返回 False。
        """
        start = time.time()
        last_log = 0.0
        while True:
            if cond():
                waited = self.time_elapsed_accounting_for_freeze(start)
                if waited > 0.3:
                    self.logger.info(f'gate [{name}] ok after {waited:.1f}s')
                return True
            self.check_combat()
            if action is not None:
                action()
            elapsed = self.time_elapsed_accounting_for_freeze(start)
            if timeout > 0 and elapsed >= timeout:
                self.logger.warning(f'gate [{name}] gave up after {elapsed:.1f}s, moving on')
                return False
            if elapsed - last_log >= self.GATE_LOG_EVERY:
                last_log = elapsed
                self.logger.warning(f'gate [{name}] not satisfied after {elapsed:.1f}s, '
                                    f'staying on field')
            self.sleep(self.GATE_POLL)

    def require_cast(self, name, send, landed, pre=None, timeout=0):
        """反复按某个键直到它真的放出去了。

        跟 require() 的区别: 这里每轮都【重新发键】。被打断时按键会被游戏吃掉,
        补发是唯一的解法。
        Args:
            send: 发键的函数。
            landed: 判据 —— "已经放出去了"返回真。
            pre: 发键之前必须先成立的条件 (比如"图标亮了"), 不成立就先不发, 省得
                在冷却里空按。不传就是每轮都发。
            timeout: >0 时的上限 (秒), 到点放弃并返回 False。默认 0 = 不设上限。
        """
        start = time.time()
        last_log = 0.0
        while True:
            if landed():
                waited = self.time_elapsed_accounting_for_freeze(start)
                self.logger.info(f'gate [{name}] cast confirmed after {waited:.1f}s')
                return True
            self.check_combat()
            if pre is None or pre():
                send()
            elapsed = self.time_elapsed_accounting_for_freeze(start)
            if timeout > 0 and elapsed >= timeout:
                self.logger.warning(f'gate [{name}] gave up after {elapsed:.1f}s, moving on')
                return False
            if elapsed - last_log >= self.GATE_LOG_EVERY:
                last_log = elapsed
                self.logger.warning(f'gate [{name}] not cast after {elapsed:.1f}s, retrying')
            self.sleep(self.GATE_POLL)

    # ============================================================ 公共段结束


    NEXT_SLOT = 3  # 打完切秧秧玄翎

    # ---- 本队的固定轴 ----
    ECHO_TO_E: float = 0.35        # Q 之后到按 E 的间隔 (秒)
    E_TO_ATTACK: float = 0.25      # E 之后到起手普攻的间隔 (秒)
    # E 之后到 R 之前的普攻时间 (秒)。原来是写死 4 段 ≈ 1.1s, 实战太短, 改成按秒算
    AXIS_A_TIME: float = 2.6
    AXIS_A_INTERVAL: float = 0.28  # 每次点击的间隔 (秒)

    # ---- F 处决: 已从千咲身上拿掉 (2026-08-25), 移交给穗穗 ----
    # 试过放在这段平A 里, 并且把计时改成扣冻结的以为就不亏了。实测那个前提不成立:
    # 击破的时停会让 time_elapsed_accounting_for_freeze 自己跳变(秧秧那边量到墙钟 0.44 秒
    # 里 elapsed 跳了 1.94 秒), 扣冻结救不回来。全队处决现在只归穗穗, 见 Suisui.wait_forte3()
    AXIS_A_POLL: float = 0.03      # A 段循环自己的轮询间隔 (秒)
    # A 段开头多久之后才开始看强化E 图标 (秒)。躲开普通E 刚放完那一下的收招/特效,
    # 那时候图标亮度不可信
    E_LIT_MIN_DELAY: float = 0.3
    # R 之后的固定缓冲 (秒)。给 0: 现在改成盯着 E 图标亮没亮 (wait_e_lit), 固定等
    # 只会让强化E 白白晚按
    POST_LIB_SETTLE: float = 0.0
    # 间隙里点普攻的间隔 (秒)。R 之后这一串缓冲原来全是干等, 人站着发愣近 1.2 秒,
    # 换成边等边点, 时长不变但手不停
    GAP_ATTACK_INTERVAL: float = 0.22
    # ---- R 之后的 F 处决 ----
    # R 之后按 F 处决 —— 已停用。击破动画的全局时停会把后面的强化E 吞掉, 为了躲它加的
    # 1.5s 缓冲又把整条轴拖长, 收益不抵成本。代码留着, 想再试改回 True
    F_BREAK_ON_LIB: bool = False
    # 按完 F 之后的缓冲 (秒), 不分处决没处决都留。
    # 试过自己找图判断处决到没到, 结果是判错的 —— 日志打 "no break prompt" 那一轮,
    # 场上其实处决了 (f_break() 内部自己那次找图是准的, 我们外面那次不准)。
    # 判错的代价很大: 以为没处决就不等, 强化E 和后面的 aaa 全被击破动画的时停吞掉。
    # 现在不判了, 这段还是边等边点普攻: 真处决了点击被时停吃掉、无害;
    # 没处决就白赚 1.5 秒输出。两种情况都不亏
    F_BREAK_WAIT: float = 1.5
    # 强化E: 0 = 短按共鸣键 (默认)。有些形态要长按才出强化段, 那就调成 1.2 走长按
    ENHANCED_E_HOLD: float = 0.0

    # ---- 强化E 触发: 读 E 图标的白像素占比, 亮了立刻按 (跟秧秧玄翎同一套) ----
    # 框架判图标亮不亮走的是像素占比 (box_highlighted → calculate_color_percentage),
    # resonance_available() 主动传 check_color=False 把这段跳过了, 所以自己读
    E_LIT_BOX: str = 'box_resonance'
    E_LIT_COLOR = {'r': (200, 255), 'g': (200, 255), 'b': (200, 255)}
    # 0.13, 跟秧秧同一个值。千咲实测亮起时 0.1619, 落在秧秧标定的亮起区间 0.158~0.211 内
    E_LIT_THRESHOLD: float = 0.13
    E_LIT_CONFIRM: int = 2         # 连续这么多次过阈值才认, 挡单点噪声
    E_LIT_POLL: float = 0.03       # 轮询间隔 (秒)
    E_LIT_MAX_WAIT: float = 1.2    # 等图标亮的上限 (秒), 到点没亮也照按
    # 采样打日志。已标定完关掉 —— 00:23 实测 R 结束那一刻 white=0.1619 就已经过阈,
    # 0.07s 按下强化E。要重新标定 (换角色/换界面) 再打开
    E_LIT_PROBE: bool = False
    E_LIT_PROBE_INTERVAL: float = 0.15
    # 强化E 被打断时补按的上限 (秒)。按一次 + gap_attack(0.5) 算一轮, 2.5 秒约四轮。
    # 到点还没消耗掉能量就交给 salvage_e_and_r 去兜
    ENHANCED_E_RETRY_TIMEOUT: float = 2.5
    ENHANCED_E_WAIT: float = 0.5   # 强化E 的演出时间 (秒), 这段也是边等边点普攻
    # 强化状态下一直点普攻的时间 (秒)。框架只有 is_forte_full(), 读不到"还剩多少",
    # 所以能量条见底这件事只能用时间兜底 —— 录一遍自己的实战, 数到条空为止再改这个值
    FORTE_DRAIN_TIME: float = 3.5
    FORTE_DRAIN_INTERVAL: float = 0.22
    DRAIN_LAST_INTERVAL: float = 0.15  # 最后一下之后到按切人键的间隔 (秒)

    # ---- R 没放出来时的补救 (被打断那一轮的救火通道) ----
    # 症状: 被怪连续打断时那 2.6 秒普攻全打在硬直里, 能量攒不出来, R 图标不亮 ——
    # 然后整条轴照着死时间往下走, 到点就把场子交给秧秧了。
    # 判据: liberation_available() 是 available('liberation', check_color=True),
    # 查的是【图标亮不亮 = 能量满没满】, 不是冷却。日志里那两条
    # "wait_until timeout ... click_liberation.<locals>.<lambda>" 就是 click_liberation
    # 在 wait_if_cd_ready 里空发了两次 R 键 —— 键发出去了, 技能没有。
    # 既然是能量没满, "再等等"没用, 得【接着打】
    LIB_RETRY_TIME: float = 3.0        # R 没亮时最多再补打多久去攒能量 (秒)
    LIB_RETRY_INTERVAL: float = 0.22
    # 补打完还是没有 R 时的兜底。强化E 和 drain_forte 都是【R 之后】才有东西可用的:
    # 没放 R 就按 E, 白白吃掉一次共鸣冷却; 没强化态就 drain, 打的是空气。
    # 所以这两步整个跳过, 改成一直打到协奏满 —— 至少保证秧秧能拿到变奏,
    # 不然下一棒也跟着废 (实测那一轮离场时 con=0.51, 秧秧 intro=False)
    NO_LIB_CON_TIME: float = 4.0       # 攒协奏最多打多久 (秒) —— 已不再用作上限, 留作参考
    NO_LIB_CON_INTERVAL: float = 0.22

    # ---- 协奏满的确认帧数 ----
    # 单帧读数会被她自己的特效糊掉: task.count_rings() 是在能量环那个圆环区域里数
    # 指定颜色的, 千咲在 CharFactory 里登记的环色是 HAVOC, 而她的强化E / 回路特效
    # 正好是同色系 —— 圆环区域被糊满就会读成"满环"。
    # 实机症状: drain_forte 刚结束那一刻 gate 立刻通过(日志里连 "ok after" 都没打,
    # 说明 <0.3s), 但场上协奏并没满, 秧秧于是拿不到变奏。
    # 连读几帧、中间换帧, 挡掉这种一闪而过的误判。
    # 【这几帧是连着读完的, 中间不点普攻】, 所以确认本身不会让她多打几下
    CON_CONFIRM: int = 3
    # 攒协奏的上限 (秒)。到点还没满就照切 —— 协奏是给下一棒的, 下一棒拿不到变奏
    # 只是退回自己的启动轴(能自愈); 而卡死在这里不能自愈。
    # 实测 01:18 秧秧那边同样的无上限写法直接把任务挂住了
    CON_FILL_TIMEOUT: float = 8.0

    # ---- 强化E / R 的保底通道 ----
    # 千咲的强化E 和 R 都要【回路能量满】才放得出来, 而回路能量只能靠普攻和普通E 攒。
    # 被怪连续打断时正常流程那几秒全打在硬直里, 能量攒不上来, 这一轮 E 和 R 一个都不放。
    # 保底的做法不是"多等一会儿"(干等能量不会涨), 而是边打边用密轮询盯着, 一亮就放
    SALVAGE_POLL: float = 0.05            # 保底通道的轮询间隔 (秒), 比正常流程密一个量级
    SALVAGE_CLICK_INTERVAL: float = 0.18  # 保底期间点普攻的间隔 (秒)
    # 保底通道的上限 (秒)。给得比较宽 —— 回路能量确实要打一会儿才回来。
    # 但必须有: 怪站着不动/无敌时能量涨不上来, 无上限就是把任务挂死
    SALVAGE_TIMEOUT: float = 12.0

    # ------------------------------------------------------------------ 路由

    def is_dps_config(self):
        return self.task and self.task.char_config.get("Chisa DPS")

    def get_char_type(self):
        if self.is_dps_config():
            return CharType.MAIN_DPS
        return super().get_char_type()

    def get_buff_time(self):
        if self.is_dps_config():
            return get_default_buff_time(CharType.MAIN_DPS)
        return super().get_buff_time()

    # ---------------------------------------------------------- 爱达千 (轴在 Denia.py)

    @property
    def is_in_denia_cycle(self) -> bool:
        team_members = 0
        for char in self.task.chars:
            if char and char.name in {'Aemeath', 'Denia'}:
                team_members += 1
        return team_members == 2

    def denia_macro(self):
        """拿到持宏的达尼娅实例。

        【按能力找, 不按名字找】: 达尼娅那份自定义没启用的话这里就该返回 None,
        然后老老实实走原版轮换 —— 而不是拿着一个没有 perform_opener 的实例崩掉。
        """
        for char in self.task.chars:
            if char is None or char is self:
                continue
            if hasattr(char, 'perform_opener') and hasattr(char, 'quick_switch'):
                return char
        return None

    def do_perform(self):
        if self.is_in_denia_cycle:
            macro = self.denia_macro()
            if macro is not None:
                if macro.opener_pending():
                    # 【标记要在跑之前落】: perform_opener 中途抛异常(脱战/任务被停)
                    # 也不能让启动轴重跑 —— reset_state 会把 armed 重新置回来
                    macro.opener_armed = False
                    macro.last_opener = time.time()
                    if macro.perform_opener(self):
                        return
                    self.logger.warning('denia opener aborted, falling back to native rotation')
                else:
                    # 启动轴跑过了: 循环轴由爱弥斯驱动。走到这里说明宏散了
                    # (切人失败/脱战重进), 打一小段把场子交给她重新起跑
                    self.logger.info('chisa: denia opener already ran, handing the field back')
                    self.continues_normal_attack(0.8)
                    return self.switch_next_char()
            else:
                self.logger.warning('denia cycle: Denia custom code is off, '
                                    'chisa falls back to the native rotation')
            return super().do_perform()

        if self.is_dps_config():
            return self.do_dps_perform()
        return self.do_team_axis()

    def get_switch_priority(self, current_char=None, has_intro=False, target_low_con=False):
        """爱达千的启动轴待跑时千咲【必须】先上场 —— 轴的第一个动作是她的 E。

        正常路径靠 switch_healer() 就把她摆上来了(她登记的是 HEALER), 这里是
        第二道保险: 玩家把"Switch to Healer"关掉时框架就不会主动选她。
        """
        if self.is_in_denia_cycle:
            macro = self.denia_macro()
            if macro is not None and macro.opener_pending():
                return SwitchPriority.MUST
        return super().get_switch_priority(current_char, has_intro, target_low_con)

    # ------------------------------------------------------------------ 本队的轴

    def do_team_axis(self):
        """Q → E → A(AXIS_A_TIME) → R → 强化E → a 到能量条空 → 切秧秧。"""
        self.check_f_on_switch = True
        if self.flying():
            self.wait_down()
        intro = self.take_intro()
        self.logger.info(f'chisa axis start (intro={intro})')

        self.click_echo(time_out=0)  # Q 声骸
        self.sleep(self.ECHO_TO_E)

        if self.click_resonance(time_out=0.5)[0]:  # E
            self.record_support_buff()
        self.sleep(self.E_TO_ATTACK)

        # A: 打满 AXIS_A_TIME 秒, 不再按段数写死 —— 段数打完会自动从第1段接上, 不会卡住。
        # 【强化E 在这段里亮了就当场按】: 亮 = 回路能量满了, 而这段原来是死等 2.6 秒
        # 打完才往下走, 亮起来也照样继续 A —— 白白晾着一个已经就绪的强化E。
        # 这一段还顺带找处决, 见 axis_attack_with_break()
        e_cast = self.axis_attack_with_break(self.AXIS_A_TIME)

        cast = self.click_liberation(wait_if_cd_ready=0.3)  # R
        if not cast:
            # 图标不亮 = 回路能量没满 (被打断的那一轮), 接着打去攒, 亮了立刻补放
            self.logger.info('chisa: liberation not ready, buying time with extra A')
            cast = self.retry_liberation()
        if cast:
            self.record_support_buff()
            self.gap_attack(self.POST_LIB_SETTLE)

        self.execute_break()  # F 处决 —— 默认关闭, 直接返回
        # R 之后回路通常会再满一次, 那就再来一发强化E。
        # A 段已经按掉过一次也照样再看 —— 两次都能吃到才是赚的
        e_cast = self.enhanced_resonance() or e_cast

        # 保底: 正常流程没打出来的, 转到密轮询通道去补 —— 强化E 和 R 都要回路能量满,
        # 而回路能量只能靠普攻和普通E 攒。被连续打断时正常流程那几秒全打在硬直里,
        # 于是这一轮 E 和 R 一个都不放, 整条轴空转
        if not cast or not e_cast:
            self.salvage_e_and_r(need_e=not e_cast, need_r=not cast)

        self.drain_forte()         # 一直 a 到能量条消失

        # 【必须打到】协奏满才准走。视频里的提醒是「然后你就一直点普攻」
        # 「直到打满协奏」。drain_forte() 是按秒数走的, 被打断时那几下打空,
        # 协奏就攒不满 —— 实测那一轮 con=0.51 就走了, 秧秧拿到 intro=False,
        # 她那条轴的第一步(变奏入场)直接作废, 一棒废两棒
        self.require('协奏满', self.con_full_confirmed, self.click,
                     timeout=self.CON_FILL_TIMEOUT)
        self.logger.info(f'chisa: leaving at con={self.task.get_current_con():.2f}')

        # 直接按数字键切秧秧 —— 走 switch_next_char() 会多打几下 A, 把节奏拖乱。
        # 【不传 assume_intro】: 让 direct_switch 自己再读一次协奏。gate 万一又误判,
        # wait_con_full() 会把真实读数打进日志 ("con not full before switch (con=…)"),
        # 而 assume_intro=True 会把这个信号盖掉 —— 不管准不准都报 intro=True
        if self.direct_switch():
            return
        self.switch_next_char()

    def retry_liberation(self):
        """R 图标没亮就接着点普攻攒能量, 亮了立刻放。

        为什么是"接着打"而不是"再等等": 图标不亮的原因是协奏能量没满
        (liberation_available 传的是 check_color=True), 不是冷却。干等能量不会自己涨,
        只有打出去才涨 —— 被打断的那一轮她前面那 2.6 秒普攻是空的, 这里就是把它补回来。
        """
        start = time.time()
        while self.time_elapsed_accounting_for_freeze(start) < self.LIB_RETRY_TIME:
            if self.liberation_available() and self.click_liberation(wait_if_cd_ready=0.3):
                self.logger.info(f'chisa: liberation recovered after '
                                 f'{self.time_elapsed_accounting_for_freeze(start):.1f}s of extra A')
                return True
            self.click()
            self.sleep(self.LIB_RETRY_INTERVAL)
        self.logger.warning(f'chisa: no liberation after {self.LIB_RETRY_TIME:.1f}s of extra A')
        return False

    def leave_without_liberation(self):
        """【已被 salvage_e_and_r() 取代, do_team_axis 不再走这条路, 留着备查】

        这一轮没放出 R 时的离场路径: 不按强化E、不 drain, 只攒协奏。
        它的思路是"这轮认输, 保住下一棒的变奏"; salvage 的思路是"补打出来",
        后者更符合实际 —— R 放不出来的原因是能量没攒够, 接着打就有了。

        强化E 和 drain_forte 都要 R 之后才有东西可用 —— 硬走一遍的代价是白吃一次共鸣
        冷却、并且带着半管协奏离场, 秧秧于是拿不到变奏, 下一棒跟着废。
        这里改成一直点普攻到协奏满, 把变奏保住 —— 协奏是硬 gate, 不设上限。
        """
        self.logger.warning('chisa: leaving without liberation, filling concerto first')
        self.require('协奏满(无R)', self.con_full_confirmed, self.click,
                     timeout=self.CON_FILL_TIMEOUT)
        if self.direct_switch():
            return
        return self.switch_next_char()

    def con_full_confirmed(self):
        """协奏满不满 —— 连读 CON_CONFIRM 帧都满才认。

        绕开 BaseChar.is_con_full() 的缓存 (`if self.current_con == 1: return True`)
        直接问 task: 那个缓存一旦被写成 1 就粘住不放, 只有"满协奏离场"才会清零,
        用它做 gate 等于把误判永久化。
        """
        for i in range(self.CON_CONFIRM):
            if not self.task.is_con_full():
                return False
            if i + 1 < self.CON_CONFIRM:
                self.task.next_frame()  # 换一帧再读, 否则读的是同一张图
        return True

    def execute_break(self):
        """R 之后按 F 处决, 然后不管处决没处决都留一段缓冲。

        f_break() 是找图触发的 —— 没有 F 提示它根本不会按, 所以无脑按没有副作用,
        也就不需要我们自己再判一次(而且判也判不准: 日志打 "no break prompt" 那一轮,
        场上其实处决了)。缓冲的意义是别让强化E 撞进击破动画的全局时停里。
        """
        if not self.F_BREAK_ON_LIB:
            return False
        self.f_break()
        self.logger.info(f'chisa: f break sent, +{self.F_BREAK_WAIT:.1f}s buffer before enhanced E')
        self.gap_attack(self.F_BREAK_WAIT)
        return True

    def axis_attack_with_break(self, duration):
        """入场之后那段平A, 期间盯着强化E 图标, 亮了就当场按。

        和框架 continues_normal_attack() 的区别有两点:
          1. 计时用 time_elapsed_accounting_for_freeze, 不是墙钟;
          2. 每轮采一次 E 图标, 亮了立刻按掉 —— 原来是死等这段打完才看, 白晾着。

        Returns:
            bool: 这段里有没有把强化E 按出去。
        """
        start = time.time()
        last_click = -1.0
        e_cast = False
        lit_hits = 0
        while True:
            elapsed = self.time_elapsed_accounting_for_freeze(start)
            if elapsed >= duration:
                break
            self.check_combat()

            # 强化E 亮了就【第一时间】按 —— 亮 = 回路能量满。
            # 只按一次: 按完之后能量被消耗, 这段剩下的时间接着 A 去攒下一发
            if not e_cast and elapsed >= self.E_LIT_MIN_DELAY:
                white = self.e_icon_white()
                lit_hits = lit_hits + 1 if white >= self.E_LIT_THRESHOLD else 0
                if lit_hits >= self.E_LIT_CONFIRM:
                    self.logger.info(f'chisa: enhanced E lit at {elapsed:.2f}s '
                                     f'(white={white:.4f}) during axis A, casting now')
                    e_cast = self.cast_enhanced_e()
                    lit_hits = 0

            if elapsed - last_click >= self.AXIS_A_INTERVAL:
                last_click = elapsed
                self.click()
            self.sleep(self.AXIS_A_POLL)
        return e_cast

    def gap_attack(self, duration):
        """间隙里保持点普攻, 别让她站着发愣。"""
        if duration > 0:
            self.continues_normal_attack(duration, interval=self.GAP_ATTACK_INTERVAL)

    def enhanced_resonance(self):
        """强化E —— 等图标真亮了立刻按, 不再固定等一个死时间。

        Returns:
            bool: 是否确认放出去了。判据是【回路能量被消耗掉】—— 强化E 要能量满才放得出,
                放出去之后能量就不满了。不用 has_cd: 强化段很可能只消耗强化态、
                不进基础冷却 (秧秧那边实测 7/7 都判错就是这个原因)。
        """
        waited = self.wait_e_lit()
        if not self.forte_ready():
            # 【别硬按】: 判据是"回路能量从满变成不满", 本来就不满的话按下去也测不出来,
            # 而且会白吃一次共鸣冷却。A 段可能已经按掉过一发了, 这里读到不满是正常的
            self.logger.info(f'chisa: forte not ready after {waited:.2f}s, skipping the enhanced E')
            return False
        landed = self.cast_enhanced_e()
        self.logger.info(f'chisa: (waited {waited:.2f}s for the icon)')
        return landed

    def cast_enhanced_e(self):
        """按强化E, 被打断就补按, 直到确认放出去 (或到上限)。

        判据是【回路能量从"满"变成"不满"】—— 强化E 要能量满才放得出, 放出去就消耗掉了。
        不用 has_cd: 强化段很可能只消耗强化态、不进基础冷却 (秧秧那边实测 7/7 全判错)。

        【为什么要补按】: 恰好在按下那一刻被打断的话, 这一发会被游戏吃掉, 而强化态还在、
        图标还亮着。原来这里是单发, 吃掉就白丢一轮强化E。现在改成"只要图标还亮着就接着按",
        pre=forte_ready 保证不会在能量已经空了的时候空按浪费冷却。
        每次补按之间隔着 gap_attack(ENHANCED_E_WAIT) —— 那既是给游戏反应的确认窗口,
        也是在打输出, 不是干等。
        """
        if not self.forte_ready():
            return False
        landed = self.require_cast(
            '强化E',
            send=self.send_enhanced_e_key,
            landed=lambda: not self.forte_ready(),
            pre=self.forte_ready,
            timeout=self.ENHANCED_E_RETRY_TIMEOUT,
        )
        self.logger.info(f'chisa enhanced E {"cast" if landed else "NOT registered"}')
        return landed

    def send_enhanced_e_key(self):
        """发一次强化E 的键, 然后边打普攻边等它生效。"""
        if self.ENHANCED_E_HOLD > 0:
            self.task.send_key(self.get_resonance_key(), down_time=self.ENHANCED_E_HOLD)
        else:
            self.send_resonance_key()
        self.gap_attack(self.ENHANCED_E_WAIT)

    def forte_ready(self):
        """回路能量满没满 —— 强化E 的前置条件。两个信号取或, 谁先亮算谁:
        框架通用的 is_forte_full(), 和 E 图标框的白像素占比。"""
        return bool(self.is_forte_full()) or self.e_icon_white() >= self.E_LIT_THRESHOLD

    def salvage_e_and_r(self, need_e, need_r):
        """正常流程没打出来的强化E / R, 在这里边打边等, 一亮就放。

        为什么不是"多等一会儿": 强化E 和 R 都要回路能量满才放得出来, 而回路能量
        只能靠【普攻和普通E】攒 —— 干等它不会自己涨。所以这里一直在打, 并且顺手
        把不在冷却的普通E 也放掉, 那同样是攒能量的手段。

        轮询间隔比正常流程密一个量级 (SALVAGE_POLL), 目的就是"亮起那一刻就按下去",
        别再错过窗口。没有上限 —— 出口是 check_combat() 和用户停任务。

        两个都缺时优先补 R (轴上 R 在强化E 前面, 而且它给全队增益)。但如果 R 还没亮
        而回路已经满了, 就先放强化E: 站着攥着不放正是"整条轴空转"的来源, 而且放完
        之后能量会重新攒, R 并不会因此永远放不出来。
        """
        self.logger.warning(f'chisa: salvage mode (need_e={need_e}, need_r={need_r})')
        start = time.time()
        last_click = -1.0
        last_log = 0.0
        while need_e or need_r:
            self.check_combat()
            elapsed = self.time_elapsed_accounting_for_freeze(start)
            if elapsed >= self.SALVAGE_TIMEOUT:
                self.logger.warning(f'chisa: salvage gave up after {elapsed:.1f}s '
                                    f'(need_e={need_e}, need_r={need_r}), moving on')
                return False
            if elapsed - last_log >= self.GATE_LOG_EVERY:
                last_log = elapsed
                self.logger.info(f'chisa salvage {elapsed:.1f}s '
                                 f'(need_e={need_e}, need_r={need_r})')

            if need_r and self.liberation_available():
                if self.click_liberation(wait_if_cd_ready=0):
                    self.record_support_buff()
                    self.logger.info(f'chisa salvage: R cast at {elapsed:.1f}s')
                    need_r = False
                continue

            if need_e and self.forte_ready():
                self.send_resonance_key(down_time=0.05)
                self.gap_attack(self.ENHANCED_E_WAIT)
                if not self.forte_ready():
                    self.logger.info(f'chisa salvage: enhanced E cast at {elapsed:.1f}s')
                    need_e = False
                continue

            # 普通E 也给回路攒能量, 不在冷却就顺手放掉
            if self.resonance_available():
                self.click_resonance(time_out=0.5)

            if elapsed - last_click >= self.SALVAGE_CLICK_INTERVAL:
                last_click = elapsed
                self.click()
            self.sleep(self.SALVAGE_POLL)

        self.logger.info(f'chisa salvage done after '
                         f'{self.time_elapsed_accounting_for_freeze(start):.1f}s')

    def wait_e_lit(self):
        """等 E 图标变成强化高亮。期间保持点普攻, 不干等。

        返回等了多久 (秒)。超时也返回, 由调用方照样按 —— 识别失灵不该把轴卡死。
        """
        start = time.time()
        hits = 0
        last_click = -1.0
        last_probe = -1.0
        while True:
            elapsed = self.time_elapsed_accounting_for_freeze(start)
            if elapsed >= self.E_LIT_MAX_WAIT:
                self.logger.info(f'chisa: e icon not lit in {self.E_LIT_MAX_WAIT:.1f}s, '
                                 f'pressing anyway')
                return elapsed

            if elapsed - last_click >= self.GAP_ATTACK_INTERVAL:
                last_click = elapsed
                self.click()

            white = self.e_icon_white()
            if self.E_LIT_PROBE and elapsed - last_probe >= self.E_LIT_PROBE_INTERVAL:
                last_probe = elapsed
                self.logger.info(f'chisa probe t={elapsed:.2f}s white={white:.4f}')

            hits = hits + 1 if white >= self.E_LIT_THRESHOLD else 0
            if hits >= self.E_LIT_CONFIRM:
                return elapsed
            self.sleep(self.E_LIT_POLL)

    def e_icon_white(self):
        """E 技能图标框里的白像素占比。读不到时返回 -1, 不让它把轴卡住。"""
        try:
            box = self.task.get_box_by_name(self.E_LIT_BOX)
            return self.task.calculate_color_percentage(self.E_LIT_COLOR, box)
        except Exception as e:
            self.logger.info(f'chisa: e icon probe failed ({e})')
            return -1

    def drain_forte(self):
        """强化状态下一直点普攻, 把能量条打空。

        用点按不用长按: 长按走的是重击, 强化普攻的段数吃不满。
        中途协奏满了也不停 —— 能量条没打完就走等于把强化段丢在场上。
        """
        start = time.time()
        while self.time_elapsed_accounting_for_freeze(start) < self.FORTE_DRAIN_TIME:
            self.click()
            left = self.FORTE_DRAIN_TIME - self.time_elapsed_accounting_for_freeze(start)
            if left <= self.FORTE_DRAIN_INTERVAL:
                self.sleep(self.DRAIN_LAST_INTERVAL)
                break
            self.sleep(self.FORTE_DRAIN_INTERVAL)
        self.logger.info('chisa forte drained')

    def on_combat_end(self, chars):
        self.reset_fixed_rotation()
        super().on_combat_end(chars)

    def record_support_buff(self):
        """记下变奏技能 / 共鸣解放给出的增益时间, 供框架的 buff 判定用。"""
        self.last_buff_time = time.time()

    def switch_out(self, con_full=False):
        support_buff_time = self.last_buff_time
        super().switch_out(con_full=con_full)
        if not self.is_dps_config():
            # 辅助形态下的增益是离场后还在的, 别被 switch_out 清掉
            self.last_buff_time = support_buff_time

    # ------------------------------------------------------------------ 旧路径 (本队不用)

    def do_fast_support(self):
        """极速辅助版: 进场就 Q/R 然后立刻走人。本队不用, 留着备查。"""
        self.check_f_on_switch = True
        if self.has_intro:
            self.record_support_buff()
            self.click_echo(time_out=0)
            return self.switch_next_char()

        if self.flying() and not self.liberation_available() and not self.resonance_available():
            self.wait_down()
        self.click_echo(time_out=0)
        if self.click_liberation():
            self.record_support_buff()
            return self.switch_next_char()

        self.click_resonance(time_out=0.5)
        return self.switch_next_char()

    def do_dps_perform(self):
        timeout = 2.5
        self.check_f_on_switch = True
        if self.has_intro:
            self.continues_normal_attack(0.8)
            timeout = 2.3
        if self.flying() and not self.liberation_available() and not self.resonance_available():
            self.wait_down()
        self.click_echo()
        start = time.time()
        under_liber = False
        while time.time() - start < timeout:
            if time.time() - start < 0.5 and self.click_liberation():
                start = time.time()
                under_liber = True
                timeout = 10
                self.sleep(0.2)
            if time.time() - start < 0.5 and not self.is_forte_full() and self.click_resonance()[0]:
                start = time.time()
                if timeout != 10:
                    timeout = 1.7
            if (under_liber or self.is_dps_config()) and self.is_forte_full() and self.perform_forte():
                self.check_f_on_switch = False
                return self.switch_next_char()
            self.click()
            self.check_combat()
            self.task.next_frame()
        self.switch_next_char()

    def perform_forte(self):
        if self.flying():
            self.wait_down()
        self.task.send_key(self.get_resonance_key(), down_time=1.2)
        if self.is_forte_full():
            return False
        self.heavy_attack(3.5)
        return True