"""
队伍共鸣链与共鸣效率配置说明：

配置条件：
全员0命（清宵 0+1，达妮娅 0+0，莫宁 0+0）。

效率面板：
1. 莫宁：260.8%（佩戴《奇幻变奏》）
2. 达妮娅：120.4%（佩戴《漪澜浮录》）
3. 清宵：106.8%（佩戴专武）

轴体说明：
实测上述配置下运行顺畅。面板数值均为向上取值，本轴容错率较高，并非严苛卡冷却的极快轴。

效率低于面板10%~20%时，只要不过低，仍可打出设计参照的完整循环。即便效率过低无法完成预设的完整流程，也能维持正常的基础循环，不会出现因缺少某个技能而卡轴或罚站的情况。更低效率极值未作测试。
"""
import time

from src.Labels import Labels
from src.char.BaseChar import BaseChar, SwitchPriority


class Qingxiao(BaseChar):
    HEAVY_TIMEOUT = 2
    HEAVY_CONFIRM = 0.25

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.must_cast_lib_this_turn = False

    def do_perform(self):
        self.must_cast_lib_this_turn = self.has_all_buff() and self.has_intro

        if not self.must_cast_lib_this_turn:
            self.cast_enhanced_resonance()
            return self.switch_next_char()

        start = time.time()
        broke_on_h2 = False
        if self.must_cast_lib_this_turn:
            while self.time_elapsed_accounting_for_freeze(start) < 18:
                self.cycle_start()
                if heavy := self.handle_heavy():
                    self.f_break()
                    if heavy == Labels.qingxiao_h2:
                        if self.task is not None and not self.liberation_available():
                            self.task.wait_until(lambda: self.liberation_available(), time_out=1.5)
                        self.click_liberation()
                        broke_on_h2 = True
                        break
                elif self.cast_enhanced_resonance():
                    pass
                else:
                    self.click()
                self.cycle_sleep()
            if not broke_on_h2:
                self.handle_heavy()

        if broke_on_h2 and self.task is not None:
            self.task.wait_until(lambda: self.task.in_team()[0], time_out=1.0)
            if self.echo_available():
                self.click_echo(time_out=0)
            self.continues_normal_attack(0.2)
        self.switch_next_char()

    def enhanced_resonance_available(self):
        return bool(self.task.find_one(Labels.qingxiao_e, threshold=0.7))

    def cast_enhanced_resonance(self):
        if not self.enhanced_resonance_available():
            return False
        return self.click_resonance(
            has_animation=True,
            animation_min_duration=0.5,
            time_out=1.5,
        )[0]

    def heavy_available(self):
        return self.task.find_one(Labels.qingxiao_h1, threshold=0.7) or self.task.find_one(Labels.qingxiao_h2,
                                                                                           threshold=0.7)

    def handle_heavy(self):
        heavy = self.heavy_available()
        if not heavy:
            return False

        start = time.time()
        dark_since = None
        exited_confirm = False
        self.task.mouse_down()
        try:
            while self.time_elapsed_accounting_for_freeze(start) < self.HEAVY_TIMEOUT:
                if self.heavy_available():
                    dark_since = None
                    self.task.next_frame()
                else:
                    if dark_since is None:
                        dark_since = time.time()
                    self.sleep(self.HEAVY_CONFIRM)
                    self.task.next_frame()
                    if not self.heavy_available():
                        exited_confirm = True
                        break
                    dark_since = None
        finally:
            self.task.mouse_up()
        self.sleep(0.01)
        if exited_confirm:
            return heavy.name
        return False

    def get_switch_priority(self, current_char=None, has_intro=False, target_low_con=False):
        if has_intro:
            from src.char.Denia import Denia
            if isinstance(current_char, Denia):
                return SwitchPriority.MUST
        return super().get_switch_priority(current_char, has_intro, target_low_con)
