import time

from src.char.BaseChar import BaseChar, SwitchPriority


class Lucilla(BaseChar):
    """Lucilla 自动战斗: 回路充能型 + 大招变身型角色。

    机制: 长按 E 或蓄力重击各攒 1 格回路能量, 攒满 3 格大招可用; 放大招后变身进入特殊形态
    (技能栏/大招图标消失, 视觉信号全失效), 固定时长输出后变回原建模, 再切人。

    穗洛绯轴里的位置: 吃穗穗延奏的 50% 攻击站场 5~6 秒, 再把延奏交给绯雪。
    """
    # ---- 攒能量 ----
    HOLD_TIME: float = 1.6  # 长按 E / 蓄力重击各攒 1 格回路能量的按键时长 (秒)
    CHARGE_TIME_OUT: float = 7.2  # 单次站场攒回路能量的总预算 (秒), 超时仍未放大招就切人
    LIBERATION_CD_SKIP: float = 1.5  # 大招 CD 超过此值(且能量没满)就放弃攒能量、直接切人省时间 (秒)

    # ---- 切人 / settle ----
    SWITCH_IN_SETTLE: float = 0.6  # 上场后等技能栏渲染稳定的 settle (秒), 之后才判大招
    # 上场后至少站这么久才允许走"提前切人"的捷径 (秒)。
    # energy_full()/liberation_available() 在刚切回来、UI 还没渲染完时会读假,
    # 那时立刻切人 = 刚上场就走, 和下一个角色构成来回乒乓, 谁也打不出东西。
    MIN_FIELD_TIME: float = 5.0
    # 离场前为把协奏攒满最多再站多久 (秒)。0 = 打完立刻切给绯雪, 不为协奏多站。
    # 代价: 协奏不满就没有延奏, 绯雪拿不到变奏入场(心念起手 + 50% 攻击的传递都靠它)。
    # 如果实跑发现绯雪经常空手接场, 调到 2~3 是个折中值。
    OUTRO_WAIT_TIMEOUT: float = 0.5
    # 变身结束到切人之间的 settle (秒)。不能省: 变身形态下 in_team() 还没恢复就切人,
    # 框架会报 "not in_team while switching" 并把这一轮战斗判定成脱战。
    POST_LIB_SETTLE: float = 0.4

    # ---- 变身 / 大招 ----
    LIBERATION_ANIMATION_TIME: float = 4.0  # 放大招后等进入变身形态的动画时长 (秒)
    LIBERATION_HEAVY_TIME: float = 15.0  # 变身后按住左键固定时长输出的总时长 (秒)
    HEAVY_PULSE_TIME: float = 0.6  # 变身输出时每拍 mouse_down 的按住时长 (秒)

    # ---- 延奏 buff 站场 ----
    # 从这些角色的延奏入场时不走"大招长CD就提前切人"的捷径 —— 手里握着 50% 攻击,
    # 提前走等于白扔。站场上限仍然是 CHARGE_TIME_OUT(7.2秒), 不会拖轴。
    # 想让她任何情况下都尽快交棒, 把这里改成 set() 即可。
    HOLD_FIELD_OUTRO = {'char_suisui'}

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.hold_field = False

    def do_perform(self):
        if self.perform_combat():
            return
        # 打完立刻切给绯雪。OUTRO_WAIT_TIMEOUT > 0 时才会为了补协奏多站一会。
        if self.build_concerto(self.OUTRO_WAIT_TIMEOUT):
            return
        self.switch_next_char()

    def perform_combat(self):
        """攒能量 -> 大招可用则放大招接输出.

        Returns:
            bool: 放出了大招(并已在 try_liberation 内切人)返回 True, 否则 False.
        """
        start = time.time()

        self.task.wait_until(lambda: self.task.in_team()[0], time_out=0.8)
        self.sleep(self.SWITCH_IN_SETTLE, check_combat=False)  # 等技能栏渲染稳定再判大招
        self.task.next_frame()

        self.hold_field = self.has_intro and self.check_outro() in self.HOLD_FIELD_OUTRO
        if self.hold_field:
            self.logger.info('Lucilla holding field: carrying suisui outro buff')

        if self.try_liberation():
            return True

        while time.time() - start < self.CHARGE_TIME_OUT:
            can_leave_early = time.time() - start >= self.MIN_FIELD_TIME

            # 能量满但放不出(短CD / 切回UI未渲染读假 / 任何原因) -> 别溢出空攒, 直接切人
            if can_leave_early and self.energy_full() and not self.liberation_available():
                self.logger.info('Lucilla energy full but liberation not castable, switch')
                break

            # 能量没满且大招在较长 CD -> 没必要攒, 切人省时间
            # 但手上有穗穗延奏 buff 时例外: 提前走 = 白扔 50% 攻击, 而且绯雪没变奏可吃
            if can_leave_early and not self.liberation_available() \
                    and self.task.get_cd('liberation') > self.LIBERATION_CD_SKIP:
                if not self.hold_field:
                    self.logger.info('Lucilla liberation on long cd, switch to save time')
                    break

            if self.try_liberation():
                return True

            self.charge_once()

        return False

    def build_concerto(self, timeout, allow_liberation=True):
        """继续攒能量/协奏, 直到协奏满 —— 保证离场时放得出延奏。

        Args:
            timeout (float): 最长等待时间, <=0 表示不等、立刻返回。
            allow_liberation (bool): 期间大招转好了要不要直接开。大招刚打完的那次补协奏
                传 False, 避免 try_liberation -> build_concerto 递归。

        Returns:
            bool: 是否已在内部切人 (攒着攒着大招好了, 走 try_liberation 那条路)。
        """
        if timeout <= 0 or self.is_con_full():
            return False
        start = time.time()
        while time.time() - start < timeout:
            if self.is_con_full():
                self.logger.info(f'Lucilla con full after {time.time() - start:.1f}s, outro ready')
                return False
            if allow_liberation and self.liberation_available() and self.try_liberation():
                return True
            self.charge_once()
        self.logger.warning('Lucilla con fill timed out, next char will get no intro')
        return False

    def charge_once(self):
        """攒 1 格回路能量: E 可用优先长按 E、否则蓄力重击.

        E 可用性只看 CD（resonance_available），图标点亮判定用 >0（与框架
        box_highlighted 的"任意白色即就绪"约定一致）。注意不要用
        current_resonance() > 0.05 这种高阈值——洛瑟菈的 E 图标小，就绪时白色
        占比实测只有约 0.7%，0.05 永远达不到，会让长按 E 分支变成死代码、
        一直走重击攒能量（"E没放出来"的根因）。
        """
        if self.resonance_available() and self.current_resonance() > 0:
            self.hold_resonance(self.HOLD_TIME)
        else:
            self.heavy_attack(self.HOLD_TIME)
        self.task.next_frame()

    def try_liberation(self):
        """大招就绪则放招(顺带先放声骸), 返回是否放出。

        仅在大招可用(能量满且无CD)时才放招; 未就绪只返回 False, 由外层(perform_combat 循环)
        统一处理攒能量/长CD切人。不能用"非长CD就放"——那会在能量没满时空放声骸/大招。
        """
        if not self.liberation_available():
            return False

        if self.echo_available():
            self.click_echo(time_out=0)
            # 声骸动画期间大招图标会短暂不可读/抖动，liberation_available() 可能瞬间
            # 读成 False。等它稳定恢复再放大招，否则 perform_liberation 的 while 循环
            # 一次没发键就退出，声骸放了、大招却没放出去（日志 "energy full but
            # liberation not castable" 就是这么来的）。
            start = time.time()
            while time.time() - start < 1.0 and not self.liberation_available():
                self.sleep(0.05, check_combat=False)
            if not self.liberation_available():
                self.logger.warning('Lucilla echo hid liberation; skip this cycle, retry later')
                return False

        self.perform_liberation()
        self.sleep(self.POST_LIB_SETTLE, check_combat=False)  # 等队伍UI回来再切, 否则会报脱战
        self.switch_next_char()  # 变身打完直接交棒, 不为协奏多站
        return True

    def energy_full(self):
        """回路能量是否已满(解放图标高亮, 忽略CD)。

        liberation_available() 把"能量满"和"无CD"绑在一起判断, 故用 check_cd=False 单看能量满,
        配合 not liberation_available() 即可识别"能量满但放不出(短CD/切回读假等)"而切人, 不攒溢出。
        """
        return self.available('liberation', check_color=True, check_cd=False)

    def perform_liberation(self):
        """放大招进入变身形态, 按住左键固定时长输出后切人.

        不调用 BaseChar.click_liberation(): 它内部 ``while not in_team()`` 在变身形态下会因
        in_team 误判卡死到超时抛异常. 这里用 liberation_available() 变 False
        (大招图标消失 = 已进入形态) 作为放出信号.

        """
        if not self.task.use_liberation:
            return

        start = time.time()
        while self.liberation_available() and time.time() - start < 1.5:
            self.send_liberation_key()
            self.sleep(0.1, check_combat=False)
        self.record_liberation_use()
        self.logger.info('Lucilla perform lib')

        self.sleep(self.LIBERATION_ANIMATION_TIME, check_combat=False)

        # 恢复调用脉冲重击, con 归零会在内部自动提前 break
        self.pulse_heavy_attack(self.LIBERATION_HEAVY_TIME)
        self.logger.info('Lucilla perform lib end')

    def pulse_heavy_attack(self, total_time):
        """变身后脉冲式重击 total_time 秒: 反复 mouse_down/sleep/mouse_up.

        每拍重新 mouse_down, 某拍被打断, 下一拍自动
        重按恢复, 保证持续输出直到连招打完. 全程 check_combat=False

        检测 con 归零以提前结束脉冲. 变身激活时 con 会变非零, 变身结束动画时 con 会短暂归零.
        若未检测到归零(如被连续打断), 则持续脉冲直到 total_time 兜底.
        """
        end = time.time() + total_time
        seen_active = False
        while time.time() < end:
            self.task.mouse_down()
            try:
                self.sleep(min(self.HEAVY_PULSE_TIME, end - time.time()), check_combat=False)
            finally:
                self.task.mouse_up()

            con = self.task.get_current_con()
            if con > 0.1:
                seen_active = True
            elif seen_active and con < 0.05:
                self.logger.info('Lucilla transform ended, stop pulse heavy early')
                break

            self.sleep(0.02, check_combat=False)

    def hold_resonance(self, duration):
        """长按共鸣技能键一段时间 (攒 1 格回路能量)。

        长按期间用 check_combat=False: 攒能量在正常态, in_combat() 偶发误判不应打断长按;
        sleep 已推进帧, 无需忙等/额外 next_frame。
        """
        self.task.send_key_down(self.get_resonance_key())
        try:
            self.sleep(duration, check_combat=False)
        finally:
            self.task.send_key_up(self.get_resonance_key())
        self.record_resonance_use()

    def get_switch_priority(self, current_char=None, has_intro=False, target_low_con=False):
        if has_intro and current_char and current_char.char_name in {'char_verina', 'char_shorekeeper',
                                                                    'char_suisui'}:
            return SwitchPriority.MUST
        return super().get_switch_priority(current_char, has_intro, target_low_con)