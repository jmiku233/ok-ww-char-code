import time

from src.char.BaseChar import BaseChar, SwitchPriority


class Hiyuki(BaseChar):
    """绯雪：首轮四居合，后续轮次参考版响应式三居合。

    适用队伍：穗穗 -> 洛瑟菈 -> 绯雪。
    首轮（本场第一个成功 R1 后）走短四居合宏；后续轮次走三居合宏，
    三居合宏逻辑完整照搬"现在的三居合"版（落地按住蓄枯霜 + 重叠按R2，
    不找图、不站桩）。R2 后带延奏直接切穗穗，打死怪换新怪后流程延续。

    机制: 一套完整普攻回满【寒意】, 每段居合消耗 100 寒意 + 1 层【武霜·居合】,
    3 段居合叠满 3 层【淬寒·枯霜】才解锁终结重击, 终结重击给 1 点【锻雪·归刃】,
    最后长按 R2 消耗它提升倍率。
    """

    # ---- 站场 ----
    FIELD_TIME_OUT: float = 16.0  # 单次站场总预算 (秒)
    INTRO_HOLD_TIMEOUT: float = 8.0  # 上场后按住攻击键等R亮的上限 (秒)
    INTRO_NORMAL_ATTACK_TIME: float = 1.2  # 变奏入场后的普攻时长 (秒)
    STANDARD_LIB_CD_MAX: float = 3.5  # lib1 CD ≤ 此值才进 perform_standard
    # 放完大招到切人前的 settle (秒)。压小: R2 之后应该立刻交棒, 别多站
    POST_LIB_SETTLE: float = 0.0
    LIB2_KENDO_COUNT: int = 4  # 六命配置：后续响应式三居合的 lib2 计数门槛
    HOLD_LIB_TIME_OUT: float = 8.0  # 长按大招的总超时 (秒)
    HOLD_LIB_CD_WAIT: float = 1.5
    POST_LIB2_TEAM_WAIT: float = 1.0  # 长按R2后等队伍UI (变身形态下常年误判, 别给太长)
    WAIT_LOCK_TIME_OUT: float = 2.0  # 重击/大招前等重新锁定敌人的上限 (秒)
    LIB_READY_WAIT: float = 2.0  # 强化重击后等大招亮起的上限 (秒)
    HEAVY_FORTE_TIME_OUT: float = 1.2  # 强化重击的等待上限 (BaseChar 写死 2 秒, 太长)
    LIB2_READY_WAIT: float = 0.8  # 收尾时等 R2 转好的上限 (秒)
    # 绯雪不按处决: 处决带全局时停, 会把按秒排好的定时宏整段打乱。
    # 全队的 F 交给穗穗和洛瑟菈(她们是反应式循环, 时停不影响)
    USE_F_BREAK: bool = False

    # ---- 后续轮次响应式三居合 ----
    # 仅用于首轮四居合结束后的每次变身。E1 升空后，长按 E2 落地并直接进入居合架势；
    # 之后完全依赖 hiyuki_left 的实时识别连点居合，不使用定时三居合宏。
    HOLD_E2: bool = True
    E1_TO_E2: float = 0.45
    HOLD_RES_TIME: float = 0.6
    POST_E2_ATTACK_TIME: float = 0.8
    POST_RES_NORMAL_ATTACK_TIME: float = 0.3

    # ---- 爆发宏 ----
    M_A_INTERVAL: float = 0.40  # 平A每段之间 (秒)
    M_AFTER_DODGE: float = 0.22  # 闪避之后到下一个输入 (秒)
    M_DODGE_TO_KENDO: float = 0.35  # 闪避进架势到点居合的间隔 (秒)，太短会被吃
    M_KENDO_SETTLE: float = 0.25  # 一发居合打完的常规间隔 (秒，macro_kendo 省略参数时用)
    M_HEAVY_HOLD: float = 0.55  # 重击按住左键蓄力的时长 (蓄不满会打成普通平A, 别轻易压)
    M_AFTER_HEAVY: float = 0.25  # 重击之后到下一个输入 (秒)
    # 第二发重击松手到开始长按E的间隔 (秒)。松手只是重击开始挥, 真正命中还要一点时间 ——
    # 给太小 E 会卡在"挥出去但还没打到"的那一段, 这一发重击就白费了
    M_HEAVY_TO_E: float = 0.40
    # 长按E飞天的时长 (秒)。要够游戏判成长按, 否则退化成点按 = 人飞不起来
    M_HOLD_E_RISE: float = 0.85
    M_AFTER_RISE: float = 0.28  # 飞天到第一发空中居合 (秒), 压太小第一发会被吞
    M_AIR_KENDO_INTERVAL: float = 0.60  # 空中两发居合之间 (秒)
    M_GROUND_KENDO_INTERVAL: float = 0.55  # 地面居合之间 (秒)
    # 长按E落地的时长 (秒)。长按落地才直接进【居合架势】, 点按只是普通落地
    M_HOLD_E_LAND: float = 0.85
    # 松开E到落地砸击走完、能接居合的时间 (秒)。
    # 注意长按 E 的那 M_HOLD_E_LAND 秒里人已经在下落了, 所以这里只需要补最后一点收招
    M_LAND_RECOVER: float = 0.20
    # hold_liberation() 也要按住蓄力。
    # 那个函数的循环条件是 liberation_available() —— R2 一放出去它立刻变 False,
    # 循环当场退出、松开 R 键, 等于一点都没蓄。宏没跑的那几轮(lib1 在 CD 等)
    # R2 就是从这条路出来的, 表现就是"最后一轮没蓄力"
    # 实测：HOLD_LIB_CHARGE 会在 R2 放出去后强制按住 9.5/4.5s 蓄力，导致
    # "枯霜后开大迟、罚站"（日志里 hold_liberation: charged 9.5s / end 14.6s）。
    # 关闭它，R2 亮起即放、进动画就结束，开大恢复正常速度。
    HOLD_LIB_CHARGE: bool = False
    # R2·归刃 蓄力时长（秒）：仅在 HOLD_LIB_CHARGE=True 时由 hold_liberation 使用，
    # 当前关闭不执行，保留定义供 hold_liberation 引用（避免 AttributeError）。
    R2_PRESS_TIME_FIRST: float = 9.50  # 第一轮 (3 次蓄力)
    R2_PRESS_TIME: float = 4.50  # 之后每轮 (1 次蓄力)
    R2_REPEAT_INTERVAL: float = 0.2  # 按住期间重发按键的间隔 (秒)

    # ---- 首轮四居合宏 ----
    # 仅本场第一个成功 R1 后执行一次；后续轮次回落到三居合宏。
    FIRST_ROUND_FOUR_IAI: bool = True
    # 二链脱战被动已生效时开启：两次 E 额外提供寒意，因此跳过两段前置 A3 -> 重击。
    # 连续波次/未脱战满 4 秒/非二链请设为 False，此时首轮改走完整四居合。
    S2_SHORT_FIRST_ROUND: bool = True
    # 首轮第四居合（地面第2段）前补的平A段数。
    # 实测首轮打完空中 2 居合后，落地前积攒的寒意只够 3 段居合，第 4 段差一次
    # 平A的量 → 开场前置从 3 加到 4，保证第 4 段居合能量够、枯霜能解锁。
    S2_OPENING_PRE_E_ATTACKS: int = 4
    SHORT_OPENING_MIN_REMAINING: float = 8.0  # 首轮短四居合宏所需的剩余场时下限 (秒)
    FULL_OPENING_MIN_REMAINING: float = 11.0  # 完整四居合宏所需的剩余场时下限 (秒)
    M_OPENING_START_SETTLE: float = 0.20  # 宏开头的起步等待 (秒)
    # 首轮四居合宏专用的时序（参考"能打4居合"的版本标定）。
    # 首轮宏用【点按E落地】(macro_tap_e)，需要完整的落地砸击动画时间；
    # 三居合宏用【长按E落地进架势】，落地等待很短。两者必须分开，否则
    # 首轮点按落地 0.2s 不够，落地砸击没走完 → A3/居合错位 → 寒意不足。
    S2_HOLD_E_RISE: float = 1.00  # 首轮飞天长按E时长 (秒)
    S2_AFTER_RISE: float = 0.30  # 首轮飞天到第一发空中居合 (秒)
    S2_AIR_KENDO_INTERVAL: float = 0.45  # 首轮空中两发居合之间 (秒)
    S2_LAND_RECOVER: float = 1.10  # 首轮点按E落地后的收招等待 (秒)，覆盖落地砸击动画

    # ---- 离场 ----
    # 协奏不满就不走: 穗穗的 MUST 要求"主C带着延奏离场", 空手走人这一切会落到洛瑟菈头上,
    # 洛瑟菈打完又切回绯雪 —— 绯洛来回乱切、穗穗一直进不来
    OUTRO_HARD_LIMIT: float = 25.0  # 绝对安全阀 (秒)
    OUTRO_STALL_TIME: float = 6.0  # 协奏这么久没涨就认输离场 (秒)
    CON_TOP_UP_CHAIN: float = 0.5  # 补协奏的普攻粒度 (秒)
    # 开始补协奏之前, 先给能量环留多久渲染时间 (秒)。
    # R2 放完时协奏其实已经满了, 但读数会滞后 —— 立刻去读会读到 0, 于是白打一两下
    CON_SETTLE_WAIT: float = 0.8
    CON_SETTLE_POLL: float = 0.1
    # True: 大招放出去之后直接切人, 完全不查协奏。
    SKIP_OUTRO_AFTER_LIB: bool = True
    # 交接时等协奏读数稳定的上限 (秒)。
    HANDOFF_CON_WAIT: float = 0.5
    HANDOFF_CON_POLL: float = 0.1
    # True: 大招之后用数字键直接切人, 不走 switch_next_char()。
    DIRECT_SWITCH_AFTER_LIB: bool = True
    DIRECT_SWITCH_INDEX: int = 1  # 大招后切到哪个队伍位置 (1-based), 穗穗通常是 1
    # 离场这一段临时关掉框架的脱战判定 —— 打完爆发时常出现"目标丢失 -> 判定脱战"的误报
    SKIP_COMBAT_CHECK_ON_LEAVE: bool = True
    LEAVE_FALLBACK_INDEX: int = 1  # switch_next_char 失败时直接按这个数字键 (0 = 关)
    # 直接切人等 in_team 确认的上限 (秒)。
    LEAVE_SWITCH_TIMEOUT: float = 3.5
    # 切人之前先等大招动画演完的上限 (秒)。动画期间 in_team() 读不出来, 发键也没用
    LIB_ANIM_WAIT: float = 4.0
    LEAVE_KEY_INTERVAL: float = 0.12

    # ---- R2 后切穗穗：索敌 + 变奏 ----
    # 仅本场确实放出过 R2 时，才走"直接切穗穗"的交接（带延奏）。
    POST_R2_WAVE_HANDOFF: bool = True
    POST_R2_WAVE_POLL: float = 0.05  # 检测窗口内的轮询间隔 (秒)
    # R2 后切穗穗前的检测窗口（秒）：窗口内一旦检测到新怪就准备切（不等满），
    # 2 秒内没刷怪才等满窗口再切。0 = 立即切。
    POST_R2_SWITCH_DELAY: float = 2.0
    # 检测到目标后、变奏切穗穗前的确认等待（秒）：先索敌锁定，再等这 0.8s
    # 确认目标稳定，然后才变奏——避免刚切穗穗目标又消失导致入场空打。
    POST_R2_TARGET_CONFIRM: float = 0.8

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.lib_permission = True
        self.lib2_count = 0  # 反应式回落里记录居合判定次数
        self.just_transformed = False  # 本次站场是否刚放出 lib1 变身
        self.r2_used = False  # 本场战斗是否已经放过 R2 —— 决定 R2 按住多久
        self._r1_transform_active = False
        self._post_r2_wave_handoff_pending = False
        # 只跨普通切人保留；在 BaseCombatTask 重读队伍/战斗结束时 reset_state 重置。
        self._first_transform_pending = True

    def switch_out(self, con_full=False):
        super().switch_out(con_full)
        self.lib2_count = 0
        self.just_transformed = False
        self._r1_transform_active = False
        self._post_r2_wave_handoff_pending = False
        # 不要重置 _first_transform_pending：同一场的后续轮次必须走三居合宏。

    def reset_state(self):
        """框架重读队伍时调用 —— 归刃层数按场累计, 这里跟着归零。"""
        super().reset_state()
        self.r2_used = False
        self.lib2_count = 0
        self.just_transformed = False
        self._r1_transform_active = False
        self._post_r2_wave_handoff_pending = False
        self._first_transform_pending = True

    # ------------------------------------------------------------------ 主流程

    def do_perform(self):
        # 声骸放最前面: 后面按住等到R亮就直接变身返回了, 放在循环里会被跳过
        self.click_echo(time_out=0)

        # 首轮：长按攻击等 R1 亮；后续轮：变奏入场打一小段。
        if self._first_transform_pending:
            if not self.liberation_available():
                self.hold_attack_until_lib()
        elif self.has_intro:
            self.continues_normal_attack(self.INTRO_NORMAL_ATTACK_TIME)

        if self.has_long_action() and self.task.get_cd('liberation') <= self.STANDARD_LIB_CD_MAX:
            self.perform_standard()

        lib_ok = False
        # 只把四居合定时宏挂到本场第一个成功 R1：首轮的枯霜、R2 与交接逻辑保持原样。
        # 后续变身直接进入 perform_lib() 的响应式三居合，靠架势标记实时收尾。
        if self.just_transformed:
            self.just_transformed = False
            if self._first_transform_pending:
                self._first_transform_pending = False
                if self.FIRST_ROUND_FOUR_IAI and self.can_run_first_round_macro():
                    macro = (self.transform_macro_heavy_s2_first_round
                             if self.S2_SHORT_FIRST_ROUND
                             else self.transform_macro_heavy_full)
                    lib_ok = macro()
                    if not lib_ok:
                        self.logger.info('hiyuki opening macro fell through, back to reactive loop')

        if not lib_ok and self.has_long_action2():
            lib_ok = self.perform_lib()
        if not lib_ok and self.lib_permission and self.liberation_available():
            lib_ok = self.hold_liberation()
        if lib_ok:
            # check_combat=False 是关键: R2 打完那一刻目标往往刚死/丢失, 带战斗判定的 sleep
            # 会抛 NotInCombatException, 于是 leave() 一次都跑不到、整个 run 循环退出
            self.sleep(self.POST_LIB_SETTLE, check_combat=False)

        # 放完大招就直接切, 不查协奏(读数滞后, 查了反而白打几下)
        self.leave(skip_outro=lib_ok and self.SKIP_OUTRO_AFTER_LIB)

    def hold_attack_until_lib(self):
        """按住攻击键直到大招(R)亮起 —— 不放E, 不闪避。"""
        start = time.time()
        self.task.mouse_down()
        try:
            while self.time_elapsed_accounting_for_freeze(start) < self.INTRO_HOLD_TIMEOUT:
                if self.liberation_available():
                    self.logger.info(f'hiyuki: liberation up after '
                                     f'{self.time_elapsed_accounting_for_freeze(start):.1f}s of holding '
                                     f'(intro={self.has_intro})')
                    return True
                self.sleep(0.1)
        finally:
            self.task.mouse_up()
        self.logger.info('hiyuki: liberation still not up after holding, fall back to standard')
        return False

    def perform_standard(self):
        """常世身: 强化重击攒心念 → 放 lib1 变身。"""
        timeout = self.FIELD_TIME_OUT
        while self.has_long_action() and self.field_elapsed() < timeout:
            # 先查大招: R 已经亮了就直接变身, 不再多按一下 E
            if self.liberation_available() and self.click_liberation():
                self.logger.debug('hiyuki perform lib1')
                self.just_transformed = True
                self._r1_transform_active = True
                return

            self.click_echo(time_out=0)
            self.click_resonance(send_click=False, time_out=0)

            if self.is_mouse_forte_full():
                self.task.click(key="right")
                self.heavy_forte_fast(self.is_mouse_forte_full)
                self.task.wait_until(self.liberation_available, post_action=self.click_with_interval,
                                     time_out=self.LIB_READY_WAIT)
                if self.click_liberation():
                    self.logger.debug('hiyuki perform lib1')
                    self.just_transformed = True
                    self._r1_transform_active = True
                    return
            else:
                self.click(interval=0.1)
            self.sleep(0.05)

    def field_elapsed(self):
        """从被切上场算起已经站了多久 (last_perform 由 BaseChar.perform 打点)。"""
        return self.time_elapsed_accounting_for_freeze(self.last_perform)

    def field_remaining(self):
        return self.field_timeout() - self.field_elapsed()

    def field_timeout(self):
        return self.FIELD_TIME_OUT

    def can_run_first_round_macro(self):
        required = (self.SHORT_OPENING_MIN_REMAINING
                    if self.S2_SHORT_FIRST_ROUND
                    else self.FULL_OPENING_MIN_REMAINING)
        remaining = self.field_remaining()
        if remaining >= required:
            return True
        self.logger.info(
            f'hiyuki opening macro needs {required:.1f}s, only {remaining:.1f}s remain; use reactive loop'
        )
        return False

    # ------------------------------------------------------------------ 爆发宏

    def macro_wait(self, sec):
        """精确等待: 直接用 time.sleep 绕过执行器。

        self.sleep() 每 0.4 秒会插进一次截图 + 战斗判定 (CombatCheck.sleep_check_interval),
        插入位置不可控, 排不了帧级时序。代价是这几百毫秒内任务无法响应暂停/停止。
        """
        if sec > 0:
            time.sleep(sec)

    def macro_attacks(self, count, interval=None, last_interval=None):
        """点按普攻固定段数。"""
        interval = self.M_A_INTERVAL if interval is None else interval
        for i in range(count):
            self.click()
            if i == count - 1 and last_interval is not None:
                self.macro_wait(last_interval)
            else:
                self.macro_wait(interval)

    def macro_heavy(self, settle=None):
        """重击: 按住左键蓄力后松开。松手那一刻就是重击打出的时刻。"""
        self.task.mouse_down()
        try:
            self.macro_wait(self.M_HEAVY_HOLD)
        finally:
            self.task.mouse_up()
        self.macro_wait(self.M_AFTER_HEAVY if settle is None else settle)

    def macro_hold_e(self, hold, settle):
        """长按共鸣技能键。时长必须跨过长按判定门槛, 否则会被当成点按。"""
        self.task.send_key_down(self.get_resonance_key())
        self.macro_wait(hold)
        self.task.send_key_up(self.get_resonance_key())
        self.record_resonance_use()
        self.logger.debug(f'hiyuki macro: held E for {hold}s')
        self.macro_wait(settle)

    def macro_kendo(self, settle=None):
        """架势中点一下普攻 = 一发居合。

        settle 可省略：首轮四居合宏最后一段居合直接跟终结重击，用默认间隔；
        三居合宏总传 M_GROUND_KENDO_INTERVAL。
        """
        self.click()
        self.macro_wait(self.M_KENDO_SETTLE if settle is None else settle)

    # ------------------------------------------------------------------ 首轮四居合宏

    def transform_macro_heavy_s2_first_round(self):
        """二链首轮短四居合。

        R1 -> A3 -> 长按 E -> 空中居合 x2 -> 点 E 落地 -> A3 -> 闪避
        -> 地面居合 x2 -> 重击 -> R2。
        首轮只补一段可调 A3 寒意；两段前置 heavy 及另一段 A3 仍删除。
        时序用 S2_* 专用常量（点按落地，落地砸击动画要 1.10s 走完）。
        """
        self.logger.info('hiyuki opening macro: short S2 4-iai sequence start')
        self.macro_wait(self.M_OPENING_START_SETTLE)
        if self.S2_OPENING_PRE_E_ATTACKS > 0:
            self.macro_attacks(self.S2_OPENING_PRE_E_ATTACKS)

        self.macro_hold_e(self.S2_HOLD_E_RISE, self.S2_AFTER_RISE)
        self.macro_kendo(self.S2_AIR_KENDO_INTERVAL)
        self.macro_kendo(self.S2_AIR_KENDO_INTERVAL)

        self.macro_tap_e(self.S2_LAND_RECOVER)
        self.macro_attacks(3)
        self.macro_dodge(self.M_DODGE_TO_KENDO)
        self.macro_kendo(self.M_GROUND_KENDO_INTERVAL)
        self.macro_kendo()

        return self.macro_finish()

    def transform_macro_heavy_full(self):
        """完整四居合，仅用于首轮未满足二链脱战资源条件时的保守回退。"""
        self.logger.info('hiyuki opening macro: full 4-iai sequence start')

        self.macro_attacks(3)
        self.macro_heavy()

        self.macro_attacks(3)
        self.macro_heavy(settle=self.M_HEAVY_TO_E)
        self.macro_hold_e(self.M_HOLD_E_RISE, self.M_AFTER_RISE)

        self.macro_kendo(self.M_AIR_KENDO_INTERVAL)
        self.macro_kendo(self.M_AIR_KENDO_INTERVAL)

        self.macro_tap_e(self.M_LAND_RECOVER)
        self.macro_attacks(3)
        self.macro_dodge(self.M_DODGE_TO_KENDO)
        self.macro_kendo(self.M_GROUND_KENDO_INTERVAL)
        self.macro_kendo()

        return self.macro_finish()

    def macro_tap_e(self, settle):
        self.task.send_key(self.get_resonance_key())
        self.record_resonance_use()
        self.logger.debug('hiyuki macro: tapped E')
        self.macro_wait(settle)

    def macro_dodge(self, settle=None):
        self.task.send_key(self.task.key_config.get('Dodge Key', 'lshift'))
        self.macro_wait(self.M_AFTER_DODGE if settle is None else settle)

    def macro_finish(self):
        """收尾: 终结重击·枯霜 → 长按大招 R2·归刃。首轮宏的校验点。

        终结重击解锁 = 3 层【淬寒·枯霜】满 = 居合确实打出去了。
        """
        if not self.lib_heavy_available():
            self.logger.warning('hiyuki macro: final heavy NOT unlocked, kendo missed')
            return False

        self.logger.info('hiyuki macro: final heavy unlocked, kendo landed')
        # 直接接终结重击, 不再 wait_locked ——
        # 那个函数用 post_action=self.click 等锁定, 没锁上时会点出一下普攻,
        # 这就是"最后一发居合完又多A了一下"。居合刚打完, 目标就在面前, 不需要重新锁
        self.heavy_forte_fast(self.lib_heavy_available)

        if not self.lib_permission:
            return False
        if not self.task.wait_until(self.liberation_available, post_action=self.click,
                                    time_out=self.LIB2_READY_WAIT):
            return False
        if self.wait_locked(self.WAIT_LOCK_TIME_OUT) and self.hold_liberation():
            self.logger.info('hiyuki macro: R2 released')
            self.lib2_count = 0
            return True
        return False

    # ------------------------------------------------------------------ 反应式回落

    def perform_lib(self):
        """后续轮次的参考三居合响应式循环。

        E1 后长按 E2 落地进架势；hiyuki_left 标记存在期间连续点普攻，
        每一次实际点按才是一段居合。LIB2_KENDO_COUNT=4 保留为六命配置。
        """
        timeout = self.field_timeout()
        is_timeout = False
        while self.has_long_action2() and self.field_elapsed() < timeout:
            if self.USE_F_BREAK:
                self.f_break()
            self.click_echo(time_out=0)

            lib_heavy_avail = self.lib_heavy_available()
            is_timeout = self.field_elapsed() >= timeout - 0.5

            if self.lib_permission and self.liberation_available() and (
                    self.lib2_count >= self.LIB2_KENDO_COUNT or is_timeout):
                if self.hold_liberation():
                    self.logger.info(f'hiyuki perform lib2 (count: {self.lib2_count}, '
                                     f'timeout: {is_timeout})')
                    self.lib2_count = 0
                    return True

            res_resonance = self.click_resonance(send_click=False, time_out=0)
            if res_resonance and res_resonance[0]:
                if is_timeout:
                    break
                if self.hold_second_resonance():
                    self.continues_normal_attack(self.POST_E2_ATTACK_TIME)
                else:
                    self.continues_normal_attack(self.POST_RES_NORMAL_ATTACK_TIME)
            elif lib_heavy_avail:
                if is_timeout:
                    break
                if self.wait_locked(self.WAIT_LOCK_TIME_OUT):
                    self.heavy_click_forte(check_fun=self.lib_heavy_available)
                if self.task.wait_until(self.liberation_available, post_action=self.click, time_out=0.5):
                    if self.wait_locked(self.WAIT_LOCK_TIME_OUT) and self.hold_liberation():
                        self.lib2_count = 0
                        return True
                self.lib2_count += 1
                self.sleep(0.1)
            elif bool(self.task.find_one('hiyuki_left', threshold=0.5)):
                # 居合架势: 标记在就一直点普攻, 每一下都是一段居合
                self.task.wait_until(lambda: not bool(self.task.find_one('hiyuki_left', threshold=0.5)),
                                     post_action=self.click, time_out=3.0)
                if is_timeout:
                    break
                self.sleep(0.1)
            elif bool(self.task.find_one('hiyuki_right', threshold=0.5)):
                self.task.click(key="right", interval=1.0)
                self.sleep(0.1)
            else:
                self.click()
            self.sleep(0.05)

        if self.lib_permission and self.liberation_available():
            if self.hold_liberation():
                self.logger.warning('hiyuki perform lib2 (final fallback)')
                self.lib2_count = 0
                return True
        return False

    def hold_second_resonance(self):
        """后续三居合的 E2：长按落地并直接进入居合架势。"""
        if not self.HOLD_E2:
            return False
        self.sleep(self.E1_TO_E2)
        self.task.send_key_down(self.get_resonance_key())
        try:
            self.sleep(self.HOLD_RES_TIME, check_combat=False)
        finally:
            self.task.send_key_up(self.get_resonance_key())
        self.record_resonance_use()
        self.logger.debug('hiyuki reactive 3-iai: held E2, landing into kendo stance')
        return True

    # ------------------------------------------------------------------ 离场

    def leave(self, skip_outro=False):
        """唯一的离场口。

        R2 后：走"索敌 + 变奏切穗穗"handoff（本场确实放过 R2 时）。
        其余：skip_outro=True 直接切人，否则补协奏后切人。
        """
        if self._post_r2_wave_handoff_pending:
            self._post_r2_wave_handoff_pending = False
            if self.try_post_r2_wave_handoff():
                return

        skip = self.SKIP_COMBAT_CHECK_ON_LEAVE
        previous = getattr(self.task, 'skip_combat_check', False)
        if skip:
            self.task.skip_combat_check = True
        try:
            if skip_outro:
                self.logger.info('hiyuki switching right after liberation, skip con check')
                if self.DIRECT_SWITCH_AFTER_LIB and self.direct_switch(self.DIRECT_SWITCH_INDEX,
                                                                       assume_intro=True):
                    return
            else:
                self.ensure_outro()
            self.switch_next_char()
        except Exception as e:
            self.logger.warning(f'hiyuki leave failed ({e}), trying direct switch')
            if not self.force_switch_out():
                raise
        finally:
            if skip:
                self.task.skip_combat_check = previous

    def try_post_r2_wave_handoff(self):
        """R2 后索敌 + 变奏切穗穗，不等怪、不打新怪。

        R2 伤害高，可能打死当前怪。分两种情况：
          - 怪还活着（目标可见）：立刻切穗穗——怪就在面前，穗穗切过去直接打，
            不用等也不用索敌确认；
          - 怪死了（目标丢失）：进 POST_R2_SWITCH_DELAY 秒窗口等新怪刷新，
            检测到新怪后先等 POST_R2_TARGET_CONFIRM(0.8s) 索敌确认目标稳定，
            再变奏切穗穗。窗口内没刷怪则等满后切。
        换怪/等新怪由穗穗那轮处理。
        """
        if not self.POST_R2_WAVE_HANDOFF or self.is_open_world_auto_combat():
            return False

        # 怪还活着：直接切穗穗，不等。
        if self.wave_target_visible():
            self.logger.debug('hiyuki post-R2: target still alive, switch immediately')
        else:
            # 怪死了，在绯雪这边安静等新怪刷新的窗口（不打怪、不发任何输入）。
            # 用 check_combat=False，怪死/脱战的瞬间不会抛异常中断切人。
            if self.POST_R2_SWITCH_DELAY > 0:
                start = time.time()
                while self.time_elapsed_accounting_for_freeze(start) < self.POST_R2_SWITCH_DELAY:
                    if self.wave_target_visible():
                        self.logger.debug('hiyuki post-R2: next target found, confirm before switch')
                        if self.POST_R2_TARGET_CONFIRM > 0:
                            self.sleep(self.POST_R2_TARGET_CONFIRM, check_combat=False)
                        break
                    if not self.task.in_team()[0]:
                        break
                    self.sleep(self.POST_R2_WAVE_POLL, check_combat=False)

        self.logger.info('hiyuki post-R2 handoff: switching to suishui directly')
        try:
            if self.direct_switch(self.DIRECT_SWITCH_INDEX, assume_intro=True):
                return True
        except Exception as e:
            self.logger.warning(f'hiyuki post-R2 direct switch failed ({e}); fall through')
        # direct_switch 失败（找不到穗穗/切人超时）时，交给 leave() 走正常切人。
        self.logger.warning('hiyuki post-R2 direct switch failed; fall through to normal switch')
        return False

    def wave_target_visible(self):
        """Passive target read for the handoff window; never sends retarget input."""
        short_target = self.task.find_one(
            self.task.get_target_names()[0],
            box='target_box_short',
            threshold=0.6,
        )
        return bool(self.has_long_action() or self.has_long_action2() or short_target)

    def ensure_outro(self):
        """协奏不满就不离场: 继续输出直到打满, 满了立刻停手去切人。"""
        # 先等读数稳定: 大招刚放完时协奏往往已经满了, 只是能量环还没渲染回来
        settle = time.time()
        while time.time() - settle < self.CON_SETTLE_WAIT:
            if self.is_con_full():
                return True
            self.sleep(self.CON_SETTLE_POLL)

        start = time.time()
        best_con = self.get_current_con()
        last_gain = time.time()
        self.logger.info(f'hiyuki con {best_con:.2f}, topping up before outro')

        while True:
            if self.is_con_full():
                self.logger.info(f'hiyuki con full after '
                                 f'{self.time_elapsed_accounting_for_freeze(start):.1f}s, switching now')
                return True

            elapsed = self.time_elapsed_accounting_for_freeze(start)
            if elapsed >= self.OUTRO_HARD_LIMIT:
                self.logger.warning('hiyuki hit outro hard limit, switching without outro')
                return False

            con = self.get_current_con()
            if con > best_con + 0.01:
                best_con = con
                last_gain = time.time()
            elif time.time() - last_gain > self.OUTRO_STALL_TIME:
                self.logger.warning(f'hiyuki con stuck at {con:.2f}, switching without outro')
                return False

            if self.USE_F_BREAK:
                self.f_break()
            if self.echo_available():
                self.click_echo(time_out=0)
                continue
            res_resonance = self.click_resonance(send_click=False, time_out=0)
            if res_resonance and res_resonance[0]:
                self.macro_hold_e(self.M_HOLD_E_LAND, self.M_LAND_RECOVER)
                self.macro_kendo(self.M_GROUND_KENDO_INTERVAL)
                continue
            if self.is_mouse_forte_full():
                self.heavy_forte_fast(self.is_mouse_forte_full)
                continue
            self.continues_normal_attack(self.CON_TOP_UP_CHAIN, until_con_full=True)

    def force_switch_out(self):
        """switch_next_char() 抛异常时的兜底。"""
        return self.direct_switch(self.LEAVE_FALLBACK_INDEX)

    def direct_switch(self, slot, assume_intro=False):
        """按数字键直接切到指定队伍位置 (1-based)。

        不走 switch_next_char(): 那个函数内部会 continues_normal_attack / click,
        大招之后不想要那一下多余的A。
        框架每次重读队伍时按 in_team() 的 index 重设 is_current_char, 状态会自己对齐。

        Returns:
            bool: 是否切过去了。
        """
        target = self.char_at_slot(slot)
        if target is None or target is self:
            return False
        # 刚放完大招时直接认定协奏是满的 —— 不再读。
        has_intro = True if assume_intro else self.wait_con_full()

        # 先等 R2 动画演完 —— 动画期间 in_team() 读不出来, 这时发切人键是白发
        anim = time.time()
        while time.time() - anim < self.LIB_ANIM_WAIT:
            if self.task.in_team()[0]:
                break
            self.sleep(0.1, check_combat=False)

        start = time.time()
        while time.time() - start < self.LEAVE_SWITCH_TIMEOUT:
            in_team, current_index, _ = self.task.in_team()
            if in_team and current_index == target.index:
                self.logger.info(f'hiyuki direct switched to slot {slot} (intro={has_intro})')
                self.handoff_to(target, has_intro)
                return True
            self.task.send_key(slot)
            self.sleep(self.LEAVE_KEY_INTERVAL, check_combat=False)
        self.logger.warning(f'hiyuki direct switch to slot {slot} failed')
        return False

    def handoff_to(self, target, has_intro):
        """把场上角色交接给 target —— 复刻 switch_next_char() 内部那套记账。"""
        self.task.in_liberation = False
        self.switch_out(con_full=has_intro)
        target.is_current_char = True
        # 这一行是框架 _choose_switch_target() 里设的, 直接切人绕开了它必须自己补
        target.has_intro = has_intro
        if has_intro and hasattr(target, 'note_intro_handoff'):
            target.note_intro_handoff()
        target.last_switch_in_time = time.time()
        if has_intro:
            now = time.time()
            self.task.add_freeze_duration(now, target.intro_motion_freeze_duration, -100)
            self.last_outro_time = now

    def wait_con_full(self):
        """短暂轮询协奏是否满 —— 用来决定交接时给不给对方变奏。"""
        start = time.time()
        while time.time() - start < self.HANDOFF_CON_WAIT:
            if self.is_con_full():
                return True
            self.sleep(self.HANDOFF_CON_POLL, check_combat=False)
        self.logger.info('hiyuki: con not full before switch, next char gets no intro')
        return False

    def char_at_slot(self, slot):
        """按队伍位置 (1-based) 取角色, 越界返回 None。"""
        index = slot - 1
        for char in self.task.chars:
            if char is not None and char.index == index:
                return char
        return None

    # ------------------------------------------------------------------ 工具

    def lib_heavy_available(self):
        """终结重击·枯霜是否已解锁 (3 层淬寒满)。"""
        return bool(self.task.find_one('hiyuki_lib_forte', threshold=0.7))

    def heavy_forte_fast(self, check_fun, time_out=None):
        """强化重击, 等待上限可调。"""
        time_out = self.HEAVY_FORTE_TIME_OUT if time_out is None else time_out
        if not check_fun():
            return False
        self.task.mouse_down()
        try:
            success = self.task.wait_until(lambda: not check_fun(), time_out=time_out)
        finally:
            self.task.mouse_up()
        self.sleep(0.05)
        return bool(success)

    def wait_locked(self, time_out):
        """等到重新锁定敌人再返回 True; 期间持续普攻, 既维持锁定又不空转。"""
        return bool(self.task.wait_until(self.has_long_action2, post_action=self.click, time_out=time_out))

    def hold_liberation(self):
        """长按大招键放 lib2。"""
        if not self.task.use_liberation:
            return False

        last_click = 0
        sent = False
        start = time.time()
        while self.task.in_team()[0] and (
                self.liberation_available() or self.task.get_cd('liberation') <= self.HOLD_LIB_CD_WAIT) \
                and time.time() - start < self.HOLD_LIB_TIME_OUT:
            if time.time() - start > last_click:
                self.task.send_key_down(self.get_liberation_key())
                sent = True
                last_click += 0.2
            self.sleep(0.05, check_combat=False)
        if sent and self.HOLD_LIB_CHARGE:
            # 循环退出 = R2 已经放出去了, 接着按住把蓄力走完
            press_time = self.R2_PRESS_TIME if self.r2_used else self.R2_PRESS_TIME_FIRST
            charge_end = time.time() + press_time
            last = 0.0
            charge_start = time.time()
            while time.time() < charge_end:
                if time.time() - charge_start >= last:
                    self.task.send_key_down(self.get_liberation_key())
                    last += self.R2_REPEAT_INTERVAL
                self.sleep(0.05, check_combat=False)
            self.r2_used = True
            self.logger.info(f'hold_liberation: charged {press_time:.1f}s')

        self.task.in_liberation = True
        self.task.send_key_up(self.get_liberation_key())

        if not sent:
            self.task.in_liberation = False
            self.logger.debug('hold_liberation sent nothing')
            return False

        self.task.wait_until(lambda: self.task.in_team()[0], time_out=self.POST_LIB2_TEAM_WAIT)
        self.task.in_liberation = False
        self.record_liberation_use()
        self.add_freeze_duration(start, time.time() - start)
        self.logger.info(f'hold_liberation end {time.time() - start:.1f}s')
        return True

    def get_switch_priority(self, current_char=None, has_intro=False, target_low_con=False):
        if has_intro and current_char and current_char.char_name in {'char_linnai', 'char_lucilla'}:
            return SwitchPriority.MUST
        return super().get_switch_priority(current_char, has_intro, target_low_con)
