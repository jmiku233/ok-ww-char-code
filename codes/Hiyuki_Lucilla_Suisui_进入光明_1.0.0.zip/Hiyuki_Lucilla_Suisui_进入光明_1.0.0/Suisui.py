import time

from src.Labels import Labels
from src.char.BaseChar import BaseChar, Elements, SwitchPriority


class Suisui(BaseChar):
    """穗穗: 效应体系专辅, 本体几乎无伤害, 全部价值压在「延奏」那一下。

    机制(决定了下面所有写法):
      浣尘时(初始态): 普攻/E突进/成功闪避攒【水云息】(上限120), 满后 E 变「醒春潮」
        进濯雨时; 变奏技能(入场)同样消耗全部水云息直接进濯雨时。
      濯雨时: 只有 15 秒, 游戏侧真实时间(不受动画冻结影响)。普攻/重击/E 攒【芳菲信】
        (上限600, E 一次回 100 最快), 普攻第3段聚怪、第4段附加【霜渐效应】。
        退出濯雨时(时间到或延奏离场)清空芳菲信 —— 整套代码最硬的约束。
      共鸣解放「山河水境」: 30 秒领域, 效应层数上限+3。
      延奏「淥水盈盈」: 消耗芳菲信 200/400/600 三档, 600 档才给下一个角色 50% 攻击。

    站场顺序(大招放最后): 进濯雨时 → 芳菲信打到 600 且协奏满 → 放大招 → 立刻延奏离场。
      大招压最后: 领域几乎全盖住洛瑟菈/绯雪输出窗口, 且放招那一刻领域已存在,
      紧接着的延奏照样进仙游碧落。
    队伍轴(穗穗 → 洛瑟菈 → 绯雪, 约 25 秒一圈), 顺序靠 get_switch_priority 钉死。
    3链「半卷疏帘邀晚照」: 施放濯雨时(含醒春潮)后, 长按普攻(重击)直接打出第4段普攻。
    """

    # ---- 濯雨时: 墙钟时间, 15 秒是游戏侧计时, 动画冻结时照样走 ----
    MISTY_WINDOW: float = 15.0  # 濯雨时总时长
    LIB_CAST_RESERVE: float = 3.0  # 窗口末尾预留给"放大招 + 切人"的时间

    # ---- 行为预算: 用 time_elapsed_accounting_for_freeze, 脚本自己的耐心 ----
    ATTACK_CHAIN_TIME: float = 1.1  # 一轮普攻连段时长, 够走完 4 段
    FORTE_POLL_CHAIN: float = 0.2  # 等芳菲信满时的普攻粒度: 越小越早发现"满了"
    CON_TOP_UP_CHAIN: float = 0.4  # 芳菲信已满、只差协奏时的普攻粒度
    ATTACK_INTERVAL: float = 0.2  # 普攻点击间隔, 别刷太快(高频点击有掉线检测风险)
    ENTER_MISTY_TIMEOUT: float = 6.0  # 攒满水云息进濯雨时的最长尝试时间
    CON_FILL_TIMEOUT: float = 5.0  # 濯雨时结束但协奏没满时, 补协奏的最长时间
    QUICK_PASS_TIMEOUT: float = 4.0  # 大招没好时的过场模式: 协奏满就走
    LIB_CD_TOLERANCE: float = 1  # 大招 CD 小于这个值就当它好了, 值得走完整套
    FORTE3_THRESHOLD: float = 0.75  # 芳菲信满档识别阈值, 0.6 太松会误判
    FORTE3_CONFIRM: int = 2  # 连续命中这么多次才认, 单帧误判不算
    MIN_MISTY_BEFORE_LIB: float = 2  # 进濯雨时不足这个秒数时不认满档 —— 物理上不可能满
    FIELD_ACTIVE_TIME: float = 26.0  # 山河水境 30 秒, 留 4 秒余量算"还在"
    HEAVY_ATTACK_DURATION: float = 0.4  # 3链下重击的按键持续时间
    XINGCHUNCHAO_WAIT: float = 0.1  # 醒春潮(强化E)后到接普攻(落地) (秒)
    LAND_TO_E_WAIT: float = 0.1  # 普攻(落地)后到点E (秒)
    E_TO_ATTACK_WAIT: float = 0.1  # 点E后到开始点普攻 (秒)
    HOLD_ATTACK_TIME: float = 6.0  # 空手入场长按普攻攒水云息的上限 (秒)
    FORTE3_TIMEOUT: float = 8.0  # 进濯雨时后这么久还没确认3层芳菲信就不再认满(默认没有满档)
    # 上一次延奏后多久内不让别人把她切回来 (25 秒轴: 有主C 24s / 无主C 26s 上游实测)
    MAIN_DPS_OUTRO_LOCKOUT: float = 50.0
    OUTRO_LOCKOUT: float = 50.0

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.last_outro = -1  # 上一次协奏满离场(真的放出延奏)的时间
        self.last_field = -1  # 上一次铺出山河水境的时间
        self.misty_start = -1  # 本次进入濯雨时的墙钟时间
        self._forte3_hits = 0  # 芳菲信满档连续命中计数
        if self.ring_index < 0:
            self.ring_index = Elements.ICE

    def reset_state(self):
        """脱战重置挂这里: on_combat_end 只对在场角色调用, 穗穗是 Healer 常已离场
        可能永远不执行; 否则上一场状态残留会让 field_active / 延奏 lockout 误判。"""
        super().reset_state()
        self.last_outro = -1
        self.last_field = -1
        self.misty_start = -1
        self._forte3_hits = 0

    # ------------------------------------------------------------------ 主流程

    def do_perform(self):
        if self.flying():
            self.wait_down()

        if self.has_intro:
            self.logger.info(f'suisui intro from {self.check_outro()}, already in misty')
            self.enter_misty_state()
            # 3链: 变奏入场后直接重击触发第4段
            self.heavy_attack(self.HEAVY_ATTACK_DURATION)
        elif self.in_misty():
            self.logger.info(f'suisui resuming misty, {self.misty_left():.1f}s left')
        elif self.worth_full_rotation():
            self.enter_misty()
        else:
            self.logger.info('suisui liberation not ready, quick pass')
            self.misty_start = -1

        if self.in_misty():
            self.perform_misty()
        else:
            self.build_concerto(self.QUICK_PASS_TIMEOUT, hold_e_forte=True)

        self.cast_field()
        self.switch_next_char()

    def enter_misty(self):
        """浣尘时: 攒水云息, 满后醒春潮进濯雨时, 并立即重击(3链)。"""
        start = time.time()
        while self.time_elapsed_accounting_for_freeze(start) < self.ENTER_MISTY_TIMEOUT:
            if self.is_e_forte_full():
                if self.click_resonance(send_click=False, time_out=0)[0]:
                    self.logger.info('suisui xingchunchao cast, misty start')
                    self.enter_misty_state()
                    self.after_xingchunchao()
                    return
            self.hold_attack_until_e()

        self.logger.warning('suisui failed to confirm misty entry, fall back to concerto build')
        self.misty_start = -1

    def hold_attack_until_e(self):
        """浣尘时空手攒水云息: 长按普攻, 只有特殊E(醒春潮/水云息满)亮起才松手。
        只认 is_e_forte_full, 不碰普通 E 避免提前进 CD; 用 time.sleep 而非 self.sleep,
        否则暂停时 sleep 空转不返回, 会卡住 finally 的 mouse_up, F9 停止后还在普攻。"""
        if self._paused():
            return
        self.task.mouse_down()
        try:
            start = time.time()
            while time.time() - start < self.HOLD_ATTACK_TIME:
                if self._paused():
                    break
                # 刷新帧: is_e_forte_full 读缓存帧, 不刷新看不到醒春潮亮起
                self.task.next_frame()
                if self.is_e_forte_full():
                    break
                time.sleep(0.05)
        finally:
            self.task.mouse_up()

    def _paused(self):
        """是否被 F9 暂停 (executor 级)。暂停时立刻停手, 别让长按/连点继续发键。"""
        executor = getattr(self.task, 'executor', None)
        return bool(executor is not None and getattr(executor, 'paused', False))

    def after_xingchunchao(self):
        """醒春潮(强化E)后的确定性开场 (仅启动轴/空手入场): 落地 → 点E → 点普攻到
        3层芳菲信 → 开大 → 协奏没满就补。"""
        self.sleep(self.XINGCHUNCHAO_WAIT, check_combat=False)
        # 普攻(落地)
        self.click()
        # 点 E
        self.sleep(self.LAND_TO_E_WAIT, check_combat=False)
        self.task.send_key(self.get_resonance_key())
        self.record_resonance_use()
        # 点普攻直到 3 层芳菲信
        self.sleep(self.E_TO_ATTACK_WAIT, check_combat=False)
        while not self.forte3_available() and self.in_misty():
            self.continues_normal_attack(self.FORTE_POLL_CHAIN, interval=self.ATTACK_INTERVAL)
        # 开大
        self.cast_field()
        # 协奏没满就补
        if not self.is_con_full():
            self.build_concerto(self.CON_FILL_TIMEOUT)
        self.logger.info('suisui xingchunchao opener done')

    def enter_misty_state(self):
        self.misty_start = time.time()
        self._forte3_hits = 0

    def in_misty(self):
        return self.misty_start > 0 and self.misty_left() > self.LIB_CAST_RESERVE

    def misty_left(self):
        if self.misty_start <= 0:
            return -1
        return self.MISTY_WINDOW - (time.time() - self.misty_start)

    def perform_misty(self):
        self.click_echo(time_out=0)
        # 重置芳菲信满档计数: after_xingchunchao 里的攒满判断会污染 _forte3_hits,
        # 这里从头计数, 否则一进来就复用旧计数误判"芳菲信满" → 提前开大离场 → 延奏低档。
        self._forte3_hits = 0

        while True:
            left = self.misty_left()
            forte_full = self.forte3_available()
            con_full = self.is_con_full()

            if forte_full and con_full:
                self.logger.info(f'suisui outro ready, {left:.1f}s misty left')
                return
            if left <= self.LIB_CAST_RESERVE:
                if con_full:
                    self.logger.info(f'suisui misty closing, outro now')
                    return
                self.logger.info('suisui misty expired without full con')
                break

            if self.resonance_available():
                self.click_resonance(send_click=False, time_out=0)
                continue
            if forte_full:
                self.cast_field()
                if self.is_con_full():
                    return
                self.continues_normal_attack(self.CON_TOP_UP_CHAIN, interval=self.ATTACK_INTERVAL,
                                             until_con_full=True)
                continue
            if self.echo_available():
                self.click_echo(time_out=0)
            self.continues_normal_attack(self.FORTE_POLL_CHAIN, interval=self.ATTACK_INTERVAL)

        self.build_concerto(self.CON_FILL_TIMEOUT)

    def build_concerto(self, timeout, hold_e_forte=False):
        start = time.time()
        while self.time_elapsed_accounting_for_freeze(start) < timeout:
            if self.is_con_full():
                return True
            if self.resonance_available() and not (hold_e_forte and self.is_e_forte_full()):
                self.click_resonance(send_click=False, time_out=0)
                continue
            if self.echo_available():
                self.click_echo(time_out=0)
            self.continues_normal_attack(self.CON_TOP_UP_CHAIN, interval=self.ATTACK_INTERVAL,
                                         until_con_full=True)
        self.logger.warning('suisui concerto build timed out')
        return False

    # ------------------------------------------------------------------ 技能 / 状态

    def cast_field(self):
        if not self.liberation_available():
            return False
        if self.click_liberation(wait_if_cd_ready=0.3):
            self.last_field = time.time()
            self.logger.info('suisui field deployed')
            return True
        return False

    def field_active(self):
        return self.last_field > 0 and time.time() - self.last_field < self.FIELD_ACTIVE_TIME

    def worth_full_rotation(self):
        return (self.liberation_available()
                or self.task.get_cd('liberation') <= self.LIB_CD_TOLERANCE
                or self.field_active())

    def forte3_available(self):
        if 0 < self.misty_start:
            elapsed = time.time() - self.misty_start
            if elapsed < self.MIN_MISTY_BEFORE_LIB:
                return False
            # 进濯雨时超过 FORTE3_TIMEOUT 秒还没确认满档, 默认没有满档。
            # 濯雨时 15 秒早已结束、芳菲信必被清空, 再认满只会卡在满档分支里死等。
            if elapsed > self.FORTE3_TIMEOUT:
                self._forte3_hits = 0
                return False
        if not self.task.find_one(Labels.suisui_forte3, threshold=self.FORTE3_THRESHOLD):
            self._forte3_hits = 0
            return False
        self._forte3_hits += 1
        return self._forte3_hits >= self.FORTE3_CONFIRM

    # ------------------------------------------------------------------ 切人

    def switch_out(self, con_full=False):
        if con_full or self.current_con == 1:
            self.last_outro = time.time()
            self.misty_start = -1
        super().switch_out(con_full=con_full)

    def on_combat_end(self, chars):
        self.misty_start = -1

    def get_switch_priority(self, current_char=None, has_intro=False, target_low_con=False):
        main_dps = self.main_dps_teammate()
        # Only in instanced auto combat, let a real Hiyuki outro override the
        # ordinary anti-return lockout.  has_intro comes from the framework's
        # actual concerto read; do not manufacture an intro for a partial bar.
        if (
            has_intro
            and current_char is not None
            and getattr(current_char, 'char_name', None) == Labels.char_hiyuki
            and current_char is main_dps
            and not self.is_open_world_auto_combat()
        ):
            return SwitchPriority.MUST

        lockout = self.MAIN_DPS_OUTRO_LOCKOUT if main_dps else self.OUTRO_LOCKOUT
        if self.time_elapsed_accounting_for_freeze(self.last_outro) < lockout \
                and self.has_other_candidate(current_char):
            return SwitchPriority.NO
        if main_dps is not None:
            if current_char is not None and current_char.is_main_dps and has_intro:
                return SwitchPriority.MUST
            if self.has_other_candidate(current_char):
                return SwitchPriority.NO
        return SwitchPriority.MUST

    def main_dps_teammate(self):
        return next((char for char in self.task.chars
                     if char is not None and char is not self and char.is_main_dps), None)

    def has_other_candidate(self, current_char):
        return any(char is not None and char is not self and char is not current_char
                   for char in self.task.chars)
