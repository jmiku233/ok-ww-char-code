import time
from ok import Logger
from src.char.BaseChar import BaseChar, Elements

_ROVER_FORM_NAMES = {
    Elements.SPECTRO: 'Rover: Spectro',
}


class Rover(BaseChar):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._bind_form_logger()

    def reset_state(self):
        self.ring_index = -1
        super().reset_state()
        self._bind_form_logger()

    @property
    def display_name(self):
        return _ROVER_FORM_NAMES.get(self.ring_index, 'Rover')

    def __repr__(self):
        return self.display_name

    def _bind_form_logger(self):
        self.logger = Logger.get_logger(self.display_name)

    def ensure_display_form(self):
        if self.ring_index >= 0:
            return
        if not self.is_current_char:
            return
        if hasattr(self.task, '_ensure_ring_index'):
            self.task._ensure_ring_index()
            self._bind_form_logger()

    def _find_teammate(self, class_name):
        # 工坊 zip 加载的是独立 class，不能用 isinstance(src.char.X)
        for char in self.task.chars:
            if char is not None and char.__class__.__name__ == class_name:
                return char
        return None

    def _in_zani_liber_insert_window(self):
        """赞妮大招插队窗口：phase 2/3 且仍在 liberation 时跑 insert 短轴。"""
        zani = self._find_teammate('Zani')
        if zani is None:
            return False
        return bool(zani.try_consume_insert_handoff())

    def do_perform(self):
        self.init()
        if not self.has_intro:
            self.sleep(0.01)
        # v25 isolate: 仅 Spectro；未确认形态也走光漂 insert，禁止 discard token
        self.intro_motion_freeze_duration = 0.92
        self.logger.info(f'rover: form-dispatch ring={self.ring_index} routine=spectro')
        if self.perform_spectro_routine():
            return
        self.switch_next_char()

    INSERT_R_TO_Q_SETTLE = 0.60

    def _do_zani_liber_insert(self):
        """赞妮大招插入：E → R → Q → 切回赞妮。"""
        self.logger.info('rover: zani liber insert short axis (E+Q+R)')
        self.init()
        if self.has_intro:
            self.continues_normal_attack(0.2)
        self.wait_down()
        if self.resonance_available():
            self.click_resonance(send_click=True)
            self.sleep(0.05)
        if self.task.use_liberation:
            liber_success = self.click_liberation(send_click=True)
            if not liber_success:
                self.logger.info('rover: liber insert R first-fail, retry loop')
                retry_start = time.time()
                while time.time() - retry_start < 2:
                    remaining = 2 - (time.time() - retry_start)
                    self.continues_normal_attack(min(0.25, remaining))
                    if time.time() - retry_start >= 2:
                        break
                    if self.click_liberation(send_click=True, wait_if_cd_ready=0):
                        liber_success = True
                        self.logger.info(f'rover: liber insert R retry-success elapsed={time.time() - retry_start:.2f}s')
                        break
            else:
                self.logger.info('rover: liber insert R first-success')
            if liber_success:
                self.logger.info(f'rover: insert R settle begin duration={self.INSERT_R_TO_Q_SETTLE:.2f}s')
                self.sleep(self.INSERT_R_TO_Q_SETTLE)
                self.logger.info(f'rover: insert R settle elapsed={self.INSERT_R_TO_Q_SETTLE:.2f}s')
        if self.echo_available():
            self.logger.info('rover: insert Q input time_out=0')
            self.click_echo(time_out=0)
            self.logger.info('rover: insert Q returned')
        if self.buff_time > 0:
            self.last_buff_time = time.time()
            self.logger.info(f'rover: insert buff refreshed buff_time={self.buff_time}')
        self.logger.info('rover: insert switch-to-zani')
        return super().switch_next_char()

    def init(self):
        previous_form = self.ring_index
        if hasattr(self.task, '_ensure_ring_index'):
            self.task._ensure_ring_index()
        if self.ring_index != previous_form:
            self._bind_form_logger()
            self.logger.info(
                f'rover: form-corrected previous={previous_form} current={self.ring_index}'
            )
            names = []
            for char in self.task.chars:
                if char is None:
                    continue
                name = getattr(char, 'display_name', char.name)
                names.append(self.task.tr(name) if getattr(self.task, '_app', None) is not None else name)
            self.task.info_set('Chars', ', '.join(names))

    def perform_spectro_routine(self):
        if self._in_zani_liber_insert_window():
            self._do_zani_liber_insert()
            return True
        if self.has_intro:
            self.continues_normal_attack(1)
        self.wait_down()
        self.heavy_attack()
        self.sleep(0.4)
        self.continues_normal_attack(0.7)
        self.click_echo(time_out=0)
        if self.is_forte_full():
            self.check_combat()
            if self.resonance_available() and self.click_resonance()[0]:
                self.continues_normal_attack(1.4)
                self.sleep(0.1)
        self.check_combat()
        if not self.click_liberation(send_click=True):
            self.click_resonance()
        return False
