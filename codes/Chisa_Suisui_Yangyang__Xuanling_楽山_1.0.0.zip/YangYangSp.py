import time

from ok import Logger

from src.char.BaseChar import BaseChar


class YangYangSp(BaseChar):
    """秧秧·玄翎 —— 队伍位置 3, 接千咲的延奏, 打完切回穗穗 (位置 1), 闭环。

    本队的轴 (do_team_axis):
        Q → 长按 A 打完能量条 (A_DRAIN_TIME 秒) → E → 保持长按 (E_TO_LIB 秒)
        → R → R 动画结束 → 按 E 的同时手不松 → 最后一个重击 → 切穗穗

    全程只有起手 Q 和最后切人时松手, 中间 E/R 都是键盘, 跟按住的鼠标不冲突。
    原来的 do_perform() (按 duration 死等、边等边找 E/R) 留在下面备查。
    """

    # ================================================================ 固定顺序切人 (公共段)
    # 这一段在 Suisui.py / Chisa.py / YangYangSp.py 三个文件里逐字一样, 改一处记得同步改三处。
    # 下面各自的常量写在这一段【之后】, 所以子类想覆盖哪个直接在下面重写就行。
    #
    # 为什么不用框架的 switch_next_char():
    #   1. 它按 get_switch_priority() 现场挑人, 顺序会漂 —— 这套轴要求死顺序;
    #   2. 它内部有三处补普攻 ("performing too fast add a normal attack"、维持锁定、
    #      切换未检测到时补点击), 打完最后一下想立刻走人时那几下 A 会把节奏拖乱。
    # 代价是框架的交接记账要自己补, 全在 handoff_to() 里。

    SWITCH_TIMEOUT: float = 2.0        # 单程切人的最长尝试时间 (秒)
    SWITCH_KEY_INTERVAL: float = 0.12  # 连按数字键的间隔 (秒)
    # 切到之后等角色站稳的时间 (秒)。很敏感 —— 实测 0.50 / 0.52 会让下一个角色的起手被吞,
    # 0.55 才稳, 别再往下压
    SWITCH_SETTLE: float = 0.55
    SETTLE_ATTACK_INTERVAL: float = 0.42
    HANDOFF_CON_WAIT: float = 0.8      # 交接时等协奏读数稳定的上限 (秒)
    HANDOFF_CON_POLL: float = 0.1
    HOLD_POLL: float = 0.1             # 长按期间轮询条件的间隔 (秒)
    # 切走前按 F 处决 —— 框架 switch_next_char() 里有 current_char.f_break(True), 直接
    # 按数字键切人会绕开它。这套轴里默认【关掉】: handoff_to() 是在 switch_to_index()
    # 之后调的, 那时候下一个角色已经站上场了, 这一下 F 会被他吃掉, 而且发生在他的 R
    # 之前 (千咲"还没按 R 就开处决"就是这么来的)。处决统一由千咲在 R 之后接
    F_BREAK_ON_HANDOFF: bool = False

    # 别人用 handoff_to() 直接切给我时打的标记, 写成类属性省掉 __init__。
    # 不能只靠 has_intro —— reset_state() 每次重读队伍都会把它清成 False, 而战斗判定
    # 一抖动就会重进战斗、重读队伍, 于是角色以为自己空手入场, 跑去走开场那套流程
    intro_pending = False
    # 切人【真正完成】那一刻的时间戳 —— in_team 认出换人成功的那一帧, 不是
    # settle_with_attack 站稳之后。循环轴的落地E 就按这个锚点计时, 差 0.55 秒
    # 就会掉进"E 按在下落段完全没反应"的失败区
    switch_confirmed_at = 0.0

    def note_intro_handoff(self):
        """被别人用直接切人的方式交接进场时调用 —— 记下"我是带着变奏上来的"。"""
        self.intro_pending = True

    def take_intro(self):
        """本次入场是否带着变奏。读完就清, 避免下一轮误判。"""
        intro = self.has_intro or self.intro_pending
        self.intro_pending = False
        return intro

    def reset_fixed_rotation(self):
        """战斗结束时调 —— 在各自的 on_combat_end() 里。"""
        self.intro_pending = False

    def direct_switch(self, slot=None, assume_intro=False):
        """按数字键直接切到指定队伍位置 (1-based), 并自己补上框架的交接记账。

        Args:
            slot: 不传就用 NEXT_SLOT。
            assume_intro: True 时不读协奏, 直接认定是满的。刚放完大招要用这个 ——
                能量环读数滞后会把 has_intro 误判成 False, 下一个角色就拿不到变奏增益。
        """
        slot = self.NEXT_SLOT if slot is None else slot
        if slot is None:
            return False
        target = self.char_at_slot(slot)
        if target is None or target is self:
            return False

        has_intro = True if assume_intro else self.wait_con_full()
        if not self.switch_to_index(target.index):
            self.logger.warning(f'direct switch to slot {slot} failed')
            return False
        self.logger.info(f'direct switched to slot {slot} ({target.char_name}, intro={has_intro})')
        self.handoff_to(target, has_intro)
        return True

    def switch_to_index(self, index):
        """按数字键切到指定队伍位置, 直到 in_team 确认切过去了。

        点击落在谁身上就由谁打出来, 所以等待期间也保持点普攻, 两边连段都不断档。
        """
        start = time.time()
        while time.time() - start < self.SWITCH_TIMEOUT:
            in_team, current_index, _ = self.task.in_team()
            if in_team and current_index == index:
                # 【先记时间戳再站稳】: settle_with_attack 要花 SWITCH_SETTLE 秒,
                # 记在它后面的话锚点整体晚 0.55 秒, 靠锚点计时的动作全跟着晚
                self.switch_confirmed_at = time.time()
                self.settle_with_attack(self.SWITCH_SETTLE)
                return True
            self.task.send_key(index + 1)
            self.click()
            self.sleep(self.SWITCH_KEY_INTERVAL, check_combat=False)
        return False

    def settle_with_attack(self, duration):
        """等 duration 秒, 期间保持点普攻, 不干等。"""
        end = time.time() + duration
        while time.time() < end:
            self.click()
            self.sleep(min(self.SETTLE_ATTACK_INTERVAL, max(0.0, end - time.time())),
                       check_combat=False)

    def handoff_to(self, target, has_intro):
        """把场上角色交接给 target —— 复刻 switch_next_char() 内部那套记账。

        直接按数字键切人绕开了框架的交接逻辑, 必须自己补上, 否则:
          - 没人的 is_current_char 是 True → get_current_char() 返回 None → 下一帧崩溃;
          - has_intro / last_outro_time 不更新, 下一个角色拿不到变奏。
        """
        if self.F_BREAK_ON_HANDOFF:
            self.f_break(check_f_on_switch=True)
        self.task.in_liberation = False
        self.switch_out(con_full=has_intro)
        target.is_current_char = True
        target.has_intro = has_intro
        if has_intro and hasattr(target, 'note_intro_handoff'):
            # has_intro 是易失的, 再给对方补一个它自己保管的持久标记
            target.note_intro_handoff()
        # 用 in_team 确认那一刻, 不是现在 —— 中间隔着 settle_with_attack 那 0.55 秒
        target.last_switch_in_time = self.switch_confirmed_at or time.time()
        self.switch_confirmed_at = 0.0
        if has_intro:
            now = time.time()
            self.task.add_freeze_duration(now, target.intro_motion_freeze_duration, -100)
            self.last_outro_time = now

    def wait_con_full(self):
        """短暂轮询协奏是否满 —— 用来决定交接时给不给对方变奏。

        不能只读一次: 打完最后一下那一刻协奏其实已经满了, 但能量环读数滞后。
        必须在【按切人键之前】读: 切走之后能量环显示的已经是新角色的了。
        """
        start = time.time()
        while time.time() - start < self.HANDOFF_CON_WAIT:
            if self.is_con_full():
                return True
            self.sleep(self.HANDOFF_CON_POLL, check_combat=False)
        self.logger.info(f'con not full before switch (con={self.get_current_con()}), '
                         f'next char gets no intro')
        return False

    def char_at_slot(self, slot):
        """按队伍位置 (1-based) 取角色, 越界返回 None。"""
        index = slot - 1
        for char in self.task.chars:
            if char is not None and char.index == index:
                return char
        return None

    def attack_chain(self, count, interval, last_interval=None):
        """点按普攻打一轮连段。

        Args:
            last_interval: 最后一段之后的间隔。后面紧接切人时传更小的值 —— 按下切人键之后
                还要等游戏识别切换完成, 那段时间最后一下的动作照样在演, 两者是重叠的。
        """
        for i in range(count):
            self.click()
            if i == count - 1 and last_interval is not None:
                self.sleep(last_interval)
            else:
                self.sleep(interval)

    def hold_until(self, cond, timeout, name):
        """轮询某个条件, 期间不动手 —— 攻击键的按下/松开由调用方管。"""
        start = time.time()
        while self.time_elapsed_accounting_for_freeze(start) < timeout:
            if cond():
                self.logger.info(f'{name} ready after '
                                 f'{self.time_elapsed_accounting_for_freeze(start):.1f}s')
                return True
            self.sleep(self.HOLD_POLL)
        self.logger.info(f'timed out waiting for {name} ({timeout:.1f}s)')
        return False


    # ---------------------------------------------- "没打到就不许切人" 的硬 gate
    # 这套轴是靠变奏/延奏一棒接一棒串起来的: 任何一棒少做一步, 代价都直接传给下一棒。
    # 实测 21:23 那一圈就是完整的传染链:
    #   穗穗 forte3 没读到 -> 硬走 Q/R -> "liberation not ready, leaving without field"
    #   -> 领域没放, 千咲上场 -> "chisa: liberation not ready" -> 整圈裸打。
    # 所以关键步骤不再"到点就走", 改成留场重试到真打出来为止。
    #
    # 【没有超时是有意的】: 给上限就等于"打不出来也走", 那这个 gate 等于没有。
    # 唯一的出口是 check_combat() —— 脱战/任务被停时它抛异常, 整条轴一起退出。
    # 怪都没了的话, "这一步没打到"本来也就不是问题了。
    GATE_POLL: float = 0.12       # gate 轮询间隔 (秒)
    GATE_LOG_EVERY: float = 3.0   # 卡住时每隔这么久打一条日志, 好在日志里一眼看出卡在哪

    def require(self, name, cond, action=None, timeout=0):
        """留场直到 cond() 成立 —— 这一步没做到就不许往下走。

        Args:
            name: 打日志用的步骤名, 卡住时就是靠它定位。
            cond: 判据, 返回真就放行。
            action: 每轮做的事, 一般传 self.click。不传就是干等 (长按期间要用这个,
                手上已经按着了, 再 click 会打断长按)。
            timeout: >0 时的上限 (秒), 到点放行并返回 False。默认 0 = 不设上限。
                【什么时候该给上限】: 这一步做不到时"照走"能自愈的, 就必须给 ——
                比如协奏没满只是让下一棒退回启动轴(那条轴本来就为空手入场准备),
                而卡死在这里不能自愈。实测 01:18 那轮 fill_con 无上限直接把任务挂住了。

        Returns:
            bool: 条件成立返回 True; 到 timeout 放弃返回 False。
        """
        start = time.time()
        last_log = 0.0
        while True:
            if cond():
                waited = self.time_elapsed_accounting_for_freeze(start)
                if waited > 0.3:
                    self.logger.info(f'gate [{name}] ok after {waited:.1f}s')
                return True
            self.check_combat()
            if action is not None:
                action()
            elapsed = self.time_elapsed_accounting_for_freeze(start)
            if timeout > 0 and elapsed >= timeout:
                self.logger.warning(f'gate [{name}] gave up after {elapsed:.1f}s, moving on')
                return False
            if elapsed - last_log >= self.GATE_LOG_EVERY:
                last_log = elapsed
                self.logger.warning(f'gate [{name}] not satisfied after {elapsed:.1f}s, '
                                    f'staying on field')
            self.sleep(self.GATE_POLL)

    def require_cast(self, name, send, landed, pre=None, timeout=0):
        """反复按某个键直到它真的放出去了。

        跟 require() 的区别: 这里每轮都【重新发键】。被打断时按键会被游戏吃掉,
        补发是唯一的解法。
        Args:
            send: 发键的函数。
            landed: 判据 —— "已经放出去了"返回真。
            pre: 发键之前必须先成立的条件 (比如"图标亮了"), 不成立就先不发, 省得
                在冷却里空按。不传就是每轮都发。
            timeout: >0 时的上限 (秒), 到点放弃并返回 False。默认 0 = 不设上限。
        """
        start = time.time()
        last_log = 0.0
        while True:
            if landed():
                waited = self.time_elapsed_accounting_for_freeze(start)
                self.logger.info(f'gate [{name}] cast confirmed after {waited:.1f}s')
                return True
            self.check_combat()
            if pre is None or pre():
                send()
            elapsed = self.time_elapsed_accounting_for_freeze(start)
            if timeout > 0 and elapsed >= timeout:
                self.logger.warning(f'gate [{name}] gave up after {elapsed:.1f}s, moving on')
                return False
            if elapsed - last_log >= self.GATE_LOG_EVERY:
                last_log = elapsed
                self.logger.warning(f'gate [{name}] not cast after {elapsed:.1f}s, retrying')
            self.sleep(self.GATE_POLL)

    # ============================================================ 公共段结束


    DISPLAY_NAME = 'Yangyang: Xuanling'
    NEXT_SLOT = 1  # 打完切回穗穗

    INTRO_PERFORM_DURATION = 8.0  # 旧路径用
    PERFORM_DURATION = 3.2        # 旧路径用

    # ---- 本队的固定轴 ----
    # 变奏入场动作的时长 (秒)。框架里 intro_motion_freeze_duration = 0.9, 这段时间
    # 按键会被游戏吃掉 —— Q 一直没释放就是按在了这里面。期间保持点普攻, 不是干等
    ENTRY_WAIT: float = 0.9
    ENTRY_ATTACK_INTERVAL: float = 0.2
    ECHO_TO_ATTACK: float = 0.3    # Q 之后到按住普攻的间隔 (秒)
    ECHO_TIMEOUT: float = 1.0      # 轮询 Q 图标可用的上限 (秒)
    ECHO_FORCE: bool = True        # 轮询到超时也没读到时, 照样盲按一次 Q
    ECHO_KEY_DOWN: float = 0.05    # 按 Q 的按下时长 (秒), 框架默认才 0.01
    # Q 之后长按普攻打空能量条的【上限】(秒) —— 兜底用, 正常在 2.2s 左右就靠 E 图标
    # 亮度判定提前退出了。判定失灵时才会走到这个上限, 所以给得比实测值宽
    A_DRAIN_TIME: float = 4.5
    # ---- F 处决: 已从秧秧身上拿掉 (2026-08-25), 移交给穗穗 ----
    # 试过放在 drain 段(等强化E 那段A), 理由是"退出靠图标不靠时间, 时停挤不掉动作"。
    # 实测这个前提不成立: 01:59:31 那轮 f break 之后, 墙钟只过了 0.44 秒,
    # time_elapsed_accounting_for_freeze 却从 1.20 跳到 3.14 —— 击破的时停把这个循环的
    # 计时基准整个搞乱了, A_DRAIN_TIME 上限和 E->R 间隔全跟着失真。
    # 现在全队的处决只归穗穗管, 见 Suisui.wait_forte3()

    # 想再试找图判定就打开: 图标亮了就提前进 E, 没亮照样打满 A_DRAIN_TIME
    E_FORTE_DETECT: bool = False
    # 开了判定时, 至少先打这么久再看图标 (秒)。压到 0.8: 观测到的跳变在 1.2s,
    # 原来 1.5 的下限会把它整个挡在外面
    MIN_FORTE_DRAIN: float = 0.8

    # ---- E 图标亮度观测 / 判定 ----
    # 框架判图标亮不亮走的是像素占比 (box_highlighted → calculate_color_percentage),
    # 不是模板匹配; resonance_available() 主动传 check_color=False 把这段跳过了。
    # E 从"普通可用"变成"强化高亮"时这个占比会跳一档, 所以先观测、再定阈值。
    # A 段期间把每次采样打进日志。定完阈值就关掉 —— 日志 I/O 本身会把采样间隔拖到
    # 0.25s 左右 (00:15 那轮实测), 直接导致按 E 慢 0.3 秒
    E_LIT_PROBE: bool = False
    E_LIT_PROBE_INTERVAL: float = 0.0   # 0 = 每轮都采, 不额外节流
    E_LIT_POLL: float = 0.03            # 这个循环自己的轮询间隔 (秒), 比公共段的 0.1 密
    # 顺带记一次 find_e_forte() 的结果做对照。默认关: 那个调用单次 110ms, 会把采样拖稀
    E_LIT_PROBE_TEMPLATE: bool = False
    E_LIT_EDGE: float = 0.05           # 记"第一次超过这个值"的时刻, 只记录不打断流程
    # >0 时用这个占比判定 E 亮, 亮了就提前进 E; -1 = 只观测不判定 (照打满 A_DRAIN_TIME)。
    # 实测: 亮起前基线 0.0000, 亮起后持续在 0.158~0.211。
    # 噪声见过 0.0942 (00:15 那轮 t=0.50s 的单点), 所以阈值抬到 0.13 卡在噪声和信号中间
    E_LIT_THRESHOLD: float = 0.13
    # 连续这么多次采样都过阈值才认。挡的是 00:04 那轮 t=1.2s 的单点噪声(前后都是 0)
    E_LIT_CONFIRM: int = 2
    E_LIT_BOX: str = 'box_resonance'   # box_highlighted 里用的就是 f'box_{name}'
    E_LIT_COLOR = {'r': (200, 255), 'g': (200, 255), 'b': (200, 255)}
    # 从按下 E 到按下 R 的【总】时间 (秒), 等大招图标亮的时间算在里面。
    # 之前拆成"长按 N 秒" + "再等图标亮", 两段加起来才是实际间隔 (4.0+1.3 / 4.5+0.7),
    # 等图标那段每次不一样, 调一个数感觉不到对应变化, 所以合成这一个
    E_TO_LIB: float = 5.85
    LIB_WAIT: float = 1.0          # 传给 click_liberation 的 wait_if_cd_ready (秒)
    # R 图标没亮时最多再等多久 (秒)。期间鼠标还按着, 普攻本身在攒能量, 不是干等
    LIB_MAX_WAIT: float = 3.0
    # R 之后等多久才按 E (秒) —— 这就是"等动画结束"的那个数。
    # click_liberation() 内部等的是【过场演出】(while not in_team), 返回时演出结束了,
    # 但收招/落地动作还在演, E 按在这段里会被吃掉。0.4 太短, 先给 0.8 试。
    # 这个数是这一步唯一的旋钮: 重击还是接不上就往上加, 加到出为止
    LIB_TO_E: float = 0.8
    WAIT_DOWN_BEFORE_E: bool = True  # 按 E 之前人还在空中的话先等落地
    # 最后那个派生重击的长按时间 (秒)。它比 E 之后那段重击短得多, 打完就该走,
    # 多按的时间纯粹是站着挨打
    FINAL_HEAVY_HOLD: float = 0.9
    # 松开攻击键到按切人键之间再等一会儿 (秒)。
    # 【1.0 -> 0.2 -> 0】"等出伤"已经全部挪进 hold_for_damage() 的 HEAVY2_TO_DAMAGE
    # (手还按着, 在打)。伤害既然已经结算完, 后摇本身没有收益, 再等就是纯站桩 ——
    # 这是"能断而且该断"的那一类动画, 直接切掉。
    # 旧值的理由 "重击的收尾还在演, 立刻切会截断它" 现在不成立了: 被截断的只剩收招动作
    # (1.6 秒, 手还按着) 了, 这里再等 1.0 秒就是纯站桩。留 0.2 只为让松手动作落地
    POST_HEAVY_WAIT: float = 0.0
    # 按 E 的按下时长 (秒)。send_resonance_key 默认才 0.01, 收招那一下可能吃不到
    E_KEY_DOWN: float = 0.05
    # ---- E 释放确认 (抗打断) ----
    # 被击退/硬直时按键会被吃掉, 而框架没有"被打断了"这个信号可读, 所以只能反过来验证:
    # E 放出去之后强化态被消耗, 图标高亮消失(白像素占比掉回阈值以下); 还亮着就是没放出去
    E_CAST_CONFIRM: bool = True
    # 交给框架的 click_resonance(): 它内部是
    #   while resonance_available(): 每 0.1s 重按一次 —— 直到技能进冷却才退出。
    # "进冷却"才是"真的放出去了"。别拿图标高亮消失当判据: 强化态自己会过期, 而且鼠标
    # 一直按着还在打, 高亮没了不代表 E 放出去了 (00:29 那轮就是这么误判过去的)
    E_CAST_TIMEOUT: float = 1.5       # 重按的上限 (秒)
    # 按 E 到按住攻击键的间隔 (秒)
    E_TO_HEAVY: float = 0.1
    # ---- R 之后那一下 E 的确认 ----
    # 判据是共鸣技能进没进冷却 (has_cd), 比 resonance_available() 硬 —— 后者只说明
    # "能按", 不说明"按中了"。大招收招/被打断都会把这一下吃掉
    POST_R_E_CONFIRM: bool = True
    # 按住之后隔多久回头确认 (秒)。确认不能放在按住【之前】: 重击是紧接着长按派生的,
    # 先等 0.3 秒再按住的话窗口就过了。这段算在 FINAL_HEAVY_HOLD 里, 总长按时间不变
    POST_R_E_CONFIRM_WAIT: float = 0.3
    POST_R_E_RETRIES: int = 2
    # 交接前等协奏读数的上限 (秒), 公共段默认 0.8。秧秧这里压到 0.3:
    # 重击一结束就要切穗穗, 而且协奏满不满在放完 R 那一刻就定了, 多等也不会变
    HANDOFF_CON_WAIT: float = 0.3

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.logger = Logger.get_logger(self.DISPLAY_NAME)

    @property
    def display_name(self):
        return self.DISPLAY_NAME

    def __repr__(self):
        return self.DISPLAY_NAME

    def on_combat_end(self, chars):
        self.reset_fixed_rotation()
        super().on_combat_end(chars)

    def do_perform(self):
        return self.do_team_axis()

    # ------------------------------------------------------------------ 本队的轴

    def do_team_axis(self):
        if self.flying():
            self.wait_down()
        intro = self.take_intro()
        self.logger.info(f'yangyang axis start (intro={intro})')

        if intro and self.ENTRY_WAIT > 0:
            # 先把变奏入场动作放完, 否则下面的 Q 会被吃掉
            self.logger.info(f'yangyang: intro motion, {self.ENTRY_WAIT:.1f}s before Q')
            self.continues_normal_attack(self.ENTRY_WAIT, interval=self.ENTRY_ATTACK_INTERVAL)

        self.cast_echo()  # Q 声骸
        self.sleep(self.ECHO_TO_ATTACK)

        self.task.mouse_down()
        try:
            # 【必须打出强化E】: drain 到上限还没亮就接着等, 别拿普通E 顶上去
            if not self.drain_forte():
                self.ensure_enhanced_e_lit()

            e_cast = self.cast_e_confirmed()  # E, 并确认真的放出去了

            if not self.cast_liberation(e_cast):
                self.logger.warning('yangyang: liberation failed, final E gets no heavy')

            # R 之后: 先松手 → 等收招演完 → 按 E → 再按住接重击。
            # 顺序是"先 E 再长按", 重击从 E 派生, 反过来接不出来
            self.task.mouse_up()
            if self.WAIT_DOWN_BEFORE_E and self.flying():
                self.logger.info('yangyang: airborne after R, waiting to land')
                self.wait_down()
            self.sleep(self.LIB_TO_E, check_combat=False)

            self.logger.info(f'yangyang: post-R E (waited {self.LIB_TO_E:.1f}s, '
                             f'flying={self.flying()}, e off cd={self.resonance_available()}, '
                             f'white={self.e_icon_white():.4f})')
            self.final_e_heavy()
        finally:
            self.task.mouse_up()

        self.sleep(self.POST_HEAVY_WAIT, check_combat=False)  # 等重击收尾演完再走

        # 保底: 最后一个重击打完协奏还没满就接着点普攻, 满了立刻走。
        # 协奏不满 = 穗穗拿不到变奏 = 她那条循环轴的前提(变奏已把她推进濯雨时)不成立,
        # 于是跑去走启动轴长按流程, 一棒废两棒
        self.fill_con_fast()

        # 直接按数字键切回穗穗, 闭环。assume_intro=True 是有意的:
        # 游戏里延奏触没触发由游戏侧的协奏值决定, 跟我们读不读得到无关。
        # 之前靠 wait_con_full() 读, 读不到就把 has_intro 记成 False, 穗穗于是以为自己
        # 空手入场, 跑去走开场长按流程 —— 而场上她其实已经被变奏推进濯雨时了
        if self.direct_switch(assume_intro=True):
            return
        self.switch_next_char()

    def cast_echo(self):
        """Q 声骸 —— 不走 click_echo(), 自己轮询 + 兜底盲按。

        click_echo() 两条路都要求 echo_available() 为 True 才发键:
          time_out=0  → 只读一帧, 读不到直接 return False;
          time_out>0  → 循环里第一句就是
                        `if not self.echo_available() and ...: break`,
                        键还没发就跳出了。
        所以图标一读不到, Q 就一次都不会按 (你看到的"Q 没释放")。
        这里改成自己轮询, 到点还读不到就盲按一次 —— 真在 CD 的话按了也没副作用。
        """
        start = time.time()
        while self.time_elapsed_accounting_for_freeze(start) < self.ECHO_TIMEOUT:
            if self.echo_available():
                self.send_echo_key(down_time=self.ECHO_KEY_DOWN)
                self.record_echo_use()
                self.logger.info(f'yangyang: echo cast after '
                                 f'{self.time_elapsed_accounting_for_freeze(start):.2f}s')
                return True
            self.sleep(self.HOLD_POLL)
        self.logger.info(f'yangyang: echo icon not detected in {self.ECHO_TIMEOUT:.1f}s '
                         f'(cd={self.has_cd("echo")}), force={self.ECHO_FORCE}')
        if self.ECHO_FORCE:
            self.send_echo_key(down_time=self.ECHO_KEY_DOWN)
            self.record_echo_use()
            return True
        return False

    # 【必须打到】E 之后长按, 等强化重击标记亮起 (mouse_forte), 亮起后继续按住,
    # 直到标记消失 = 强化重击真的打出去了。判据用框架的 find_mouse_forte ——
    # 它是专门找重击标记的模板匹配, 比读 E 图标亮度硬得多:
    # 后者在 R 之后那一步实测 9 次采样峰值全是 0.12, 阈值 0.13, 一次都没过
    # ---- 强化E / 强化重击 的保底 ----
    # 秧秧的普攻全在地面: 怪一飞起来就打不到 -> 回路不消耗 -> 强化E 不亮。
    # 这时候【绝对不能盲按 E】—— 放出去的是普通E, 白吃一次共鸣冷却, 强化重击也就永远
    # 不会亮, 后面 R 会在没有重击伤害的情况下放掉, 那是整轮最大的一块伤害。
    # 所以 drain_forte 到上限还没亮时不往下走, 接着等。手一直按着, 怪一落地就能继续打。
    E_LIT_LONG_WAIT: float = 20.0   # drain 之后再等强化E 亮起的上限 (秒)
    E_LIT_LONG_POLL: float = 0.05
    # 等强化重击亮起的上限 (秒)。【必须有上限】—— 无上限的 gate 把任务挂死过一次
    HEAVY_LIT_WAIT: float = 12.0

    HEAVY_LIT_MIN: float = 0.8      # E 之后至少按住这么久再开始看标记, 躲开 E 之前的残留读数

    # ---- 强化E 被打断的保底 ----
    # 判据链: 强化E 按进去 -> 能量被消耗 -> 强化重击亮起。
    # 反过来, "强化重击一直不亮 + E 图标又亮了" = 上一发 E 被吞了, 立刻补按。
    E_RELIGHT_POLL: float = 0.04    # 盯 E 图标的轮询间隔 (秒)。要快, 亮起那一刻就得按下去
    E_RELIGHT_CONFIRM: int = 2      # 连续这么多次过阈值才认, 挡单帧噪声
    # 两次补按之间至少隔这么久 (秒)。按下去到"能量被消耗、图标灭掉"有渲染延迟,
    # 不留这个间隔会在同一次生效的 E 上连按好几发, 把后面的段数打乱
    E_RELIGHT_MIN_GAP: float = 0.6
    # 强化重击【标记亮起 -> 伤害结算】的间隔 (秒)。手一直按着, 这段不是干等。
    #
    # 【别再用"标记消失"当判据】: 实测标记要到重击整个结束之后很久才掉 ——
    # E 后那次等了 6.9s, R 后那次 5.5s, 比真正的出伤晚了将近 3 秒。再叠上原来那
    # 1.6 秒缓冲, 实机量出来的结果是: 放 R 比出伤晚 4.38 秒、切穗穗比出伤晚 5.36 秒,
    # 全是站桩。所以改成【从标记亮起那一刻起算固定时长】—— 锚点仍然是识别到的事件,
    # 只有这一段是时间。
    #
    # 两个重击的动画长度不一样, 分开给:
    #   E 后那个是向下劈, 慢。视频交叉验证: E -> 爆炸出伤 = 5.72s(游戏内时钟,
    #   这段没有过场冻结), 减掉 E -> 标记亮起的约 1.5s, 得 4.2s
    # 标定过程: 4.30(视频推算) -> 4.80(怀疑被吞, 加 0.5) -> 4.37(量出还能缩 0.43)
    #        -> 4.87(还是觉得被吞, 再加 0.5)
    # 【这个值在 4.3~4.9 之间来回震荡了三轮】, 说明"从标记亮起固定等 N 秒"这个模型
    # 可能不够准 —— 真实的出伤时刻大概率每轮都不一样(取决于连段打到第几段时重击派生)。
    # 再调之前先看日志里 hold_for_damage 打的 marker still up: 如果它有时 True 有时 False,
    # 那就是这个模型到头了, 得换个判据而不是继续调数
    #        -> 4.77 -> 4.67(各缩 0.1)
    HEAVY1_TO_DAMAGE: float = 4.67
    #   R 后那个短得多。2.70 是单轮反推的, 偏大 —— 实机量到"第二段重击出伤到切穗穗"
    #   还多站了 0.95 秒。原来的时间线是 标记亮起 +2.70 松手 +0.20(POST_HEAVY_WAIT)
    #   才切, 即 2.90; 减掉多余的 0.95 得 1.95, 那才是标记亮起到出伤的真实间隔。
    #   这 0.95 秒从两处砍: 这个常数 2.70 -> 1.95, POST_HEAVY_WAIT 0.20 -> 0
    HEAVY2_TO_DAMAGE: float = 1.95

    # ---- 离场前的协奏保底 ----
    # 轮询比公共段的 gate (GATE_POLL=0.12) 密, 满的那一刻就走, 不多站一帧
    CON_POLL: float = 0.04
    CON_CLICK_INTERVAL: float = 0.18
    # 连读这么多帧都满才认。单帧读数会被特效糊到: task.count_rings() 是在能量环那个
    # 圆环区域里数颜色的, 大招/重击的特效盖上去就可能读成满环
    CON_CONFIRM: int = 3
    # 攒协奏的上限 (秒)。到点还没满就照切 —— 见 fill_con_fast() 里的说明
    CON_FILL_TIMEOUT: float = 8.0

    def con_full_confirmed(self):
        """协奏满不满 —— 连读 CON_CONFIRM 帧都满才认, 中间换帧。

        绕开 BaseChar.is_con_full() 的缓存 (`if self.current_con == 1: return True`):
        那个缓存一旦被写成 1 就粘住, 只有"满协奏离场"才清零, 拿它做判据会把误判永久化。
        """
        for i in range(self.CON_CONFIRM):
            if not self.task.is_con_full():
                return False
            if i + 1 < self.CON_CONFIRM:
                self.task.next_frame()
        return True

    def fill_con_fast(self):
        """保底: 最后一个重击打完协奏还没满就接着点普攻, 满了立刻切。

        【这一条必须有上限, 和别的 gate 不一样】: 协奏是给下一棒的 —— 穗穗拿不到变奏
        只是退回启动轴, 那条轴本来就是给空手入场准备的, 能自愈; 而卡在这里不能自愈。
        实测 01:18 那一轮 R 没放出来, 协奏只有 0.26, 秧秧没了 R 和强化重击, 光靠普攻
        根本攒不满 —— 无上限的写法直接把整个任务挂在这儿了 (日志停在那一行再无下文)。
        """
        if self.con_full_confirmed():
            return True
        self.logger.warning(f'yangyang: con not full after the final heavy '
                            f'(con={self.task.get_current_con():.2f}), filling before switch')
        start = time.time()
        last_click = -1.0
        last_log = 0.0
        while True:
            self.check_combat()
            if self.con_full_confirmed():
                self.logger.info(f'yangyang: con full after '
                                 f'{self.time_elapsed_accounting_for_freeze(start):.1f}s of extra A')
                return True
            elapsed = self.time_elapsed_accounting_for_freeze(start)
            if elapsed >= self.CON_FILL_TIMEOUT:
                self.logger.warning(
                    f'yangyang: con still {self.task.get_current_con():.2f} after '
                    f'{elapsed:.1f}s — 攒不动了, 照切; 穗穗会退回启动轴自愈')
                return False
            if elapsed - last_log >= self.GATE_LOG_EVERY:
                last_log = elapsed
                self.logger.info(f'yangyang: filling con {self.task.get_current_con():.2f} '
                                 f'({elapsed:.1f}s)')
            if elapsed - last_click >= self.CON_CLICK_INTERVAL:
                last_click = elapsed
                self.click()
            self.sleep(self.CON_POLL)

    # ---- 出伤保底: 用"图标暗下去"当锚点 —— 【已停用, dark_floor 默认 False】----
    # 想法是对的: 实机量出"强化重击图标暗下去 -> 最后一段伤害出完 = 1.50 秒"
    # (30S15 - 28S65), 而"图标亮起"到"真正派生出重击"中间隔着一段连段, 会随 E 的
    # 早晚而漂 —— 这大概就是 HEAVY1_TO_DAMAGE 在 4.30/4.80/4.37/4.87/4.67 之间
    # 震荡的原因。
    # 【但接不上这个框架】: 我们能读到的 is_mouse_forte_full() (task.find_mouse_forte)
    # 在这整段里【从来不会变暗】—— 实测 04:18/04:19 两轮日志都是 "dark at n/a",
    # 于是保底每轮白等满 HEAVY_DARK_MAX_EXTRA, 4.7 秒被拖成 7.73 秒。
    # 也就是说: 玩家眼睛看的那个图标, 和 find_mouse_forte 匹配的不是同一个东西。
    # 要用这条 1.50 秒的测量, 得先有一个真能读出"暗下去"的判据 —— 需要在它暗的那一刻
    # 抓一张实机截图来定位是 HUD 上哪个元素。在那之前别再打开 dark_floor
    HEAVY_DARK_TO_DAMAGE: float = 1.50
    # 等"暗下去 + 1.50" 最多比原计划多等多久 (秒), 防止图标一直不暗时无限拖
    HEAVY_DARK_MAX_EXTRA: float = 3.0

    def hold_for_damage(self, name, delay, dark_floor=False):
        """标记亮起之后继续按住, 让强化重击把伤害打完。

        手上必须已经按住, 期间【不点普攻】—— 再 click 会把长按打断。

        Args:
            delay: 从【标记亮起】算起至少按住多久 (秒)。
            dark_floor: 开了之后再加一条【保底】—— 一旦看到标记暗下去(重击被消耗掉),
                就从那一刻起再等 HEAVY_DARK_TO_DAMAGE 秒。两个条件取晚的那个。
                治的是"E 放晚了 -> 重击整体后移 -> 只按 delay 会在伤害没打完时就 R"。
        """
        start = time.time()
        dark_at = -1.0
        while True:
            elapsed = self.time_elapsed_accounting_for_freeze(start)
            if dark_floor and dark_at < 0 and not self.is_mouse_forte_full():
                dark_at = time.time()
                self.logger.info(f'yangyang: [{name}] marker went dark at +{elapsed:.2f}s, '
                                 f'+{self.HEAVY_DARK_TO_DAMAGE:.2f}s more for the damage')
            if elapsed >= delay:
                if dark_at < 0:
                    # 还没暗: 没开保底就按原计划走; 开了就再宽限一会儿等它暗
                    if not dark_floor or elapsed >= delay + self.HEAVY_DARK_MAX_EXTRA:
                        if dark_floor:
                            self.logger.warning(
                                f'yangyang: [{name}] marker never went dark within '
                                f'+{self.HEAVY_DARK_MAX_EXTRA:.1f}s, going by the timer')
                        break
                elif time.time() - dark_at >= self.HEAVY_DARK_TO_DAMAGE:
                    break
            self.check_combat()
            self.sleep(self.HOLD_POLL)
        total = self.time_elapsed_accounting_for_freeze(start)
        self.logger.info(f'yangyang: [{name}] held {total:.2f}s after the marker lit '
                         f'(planned {delay:.1f}s, dark at '
                         f'{"n/a" if dark_at < 0 else f"+{dark_at - start:.2f}s"}, '
                         f'marker up now: {bool(self.is_mouse_forte_full())})')

    def ensure_enhanced_e_lit(self):
        """drain_forte 到上限还没亮时接着等 —— 等到强化E 真的亮起来为止。

        为什么不直接按: 秧秧普攻打不到空中的怪, 回路就不消耗, 强化E 也就不亮。
        这时候按下去放的是普通E —— 白吃一次共鸣冷却, 而且强化重击永远不会亮,
        后面 R 就在没有重击伤害的情况下放掉了。
        期间手一直按着(调用方管着 mouse_down), 怪一落地就能接着打, 所以不是干等。
        """
        start = time.time()
        hits = 0
        peak = 0.0
        last_log = 0.0
        while True:
            elapsed = self.time_elapsed_accounting_for_freeze(start)
            if elapsed >= self.E_LIT_LONG_WAIT:
                self.logger.warning(f'yangyang: enhanced E never lit in +{elapsed:.1f}s '
                                    f'(peak white={peak:.4f}) — 怪可能一直在空中, 照按')
                return False
            self.check_combat()
            white = self.e_icon_white()
            if white > peak:
                peak = white
            hits = hits + 1 if white >= self.E_LIT_THRESHOLD else 0
            if hits >= self.E_LIT_CONFIRM:
                self.logger.info(f'yangyang: enhanced E lit after +{elapsed:.1f}s of extra wait '
                                 f'(white={white:.4f})')
                return True
            if elapsed - last_log >= self.GATE_LOG_EVERY:
                last_log = elapsed
                self.logger.warning(f'yangyang: still waiting for enhanced E +{elapsed:.1f}s '
                                    f'(white={white:.4f}) — 打不到怪? 回路没在消耗')
            self.sleep(self.E_LIT_LONG_POLL)

    def hold_through_enhanced_heavy(self, e_cast):
        """E 之后手不松, 打到强化重击亮起、打出去、出伤 —— 这一步没做完不许放 R。

        视频里的提醒是连着的四句:
          「然后按住普攻不松手」→「然后我们看到秧秧向下劈」→「有一个爆炸」
          →「这个爆炸出伤以后，直接释放大招」
        「爆炸出伤以后」才是放 R 的信号, 不是"看到向下劈就放"。

        期间【不点普攻】—— 手上已经按住了, 再 click 会把长按打断。

        【等强化重击的时候要盯着 E 图标】: 机制上强化E 按进去了能量就被消耗、强化重击
        随即亮起, 所以"强化重击一直不亮"就等于"这一发 E 没进去"(被打断吞掉了)。
        没进去的话 E 图标后面还会再亮一次 —— 那时候必须马上补按接上强化重击。
        原来这里是 require('强化重击亮起', ...) 无上限【干等】, 不重按 E,
        被打断的那一轮就一路卡在这儿, 后面的 R 和整条轴跟着废。
        """
        while self.time_elapsed_accounting_for_freeze(e_cast) < self.HEAVY_LIT_MIN:
            self.sleep(self.HOLD_POLL)

        start = time.time()
        last_e = e_cast
        hits = 0
        recasts = 0
        last_log = 0.0
        while not self.is_mouse_forte_full():
            self.check_combat()
            if self.time_elapsed_accounting_for_freeze(start) >= self.HEAVY_LIT_WAIT:
                self.logger.warning(
                    f'yangyang: enhanced heavy never lit in {self.HEAVY_LIT_WAIT:.1f}s '
                    f'({recasts} recasts) — 放 R 走人, 这轮少一段重击伤害')
                return
            white = self.e_icon_white()
            hits = hits + 1 if white >= self.E_LIT_THRESHOLD else 0
            if (hits >= self.E_RELIGHT_CONFIRM
                    and time.time() - last_e >= self.E_RELIGHT_MIN_GAP):
                recasts += 1
                self.logger.warning(
                    f'yangyang: E lit again at +'
                    f'{self.time_elapsed_accounting_for_freeze(start):.1f}s (white={white:.4f}) '
                    f'-> last cast was eaten, recasting (#{recasts})')
                self.send_resonance_key(down_time=self.E_KEY_DOWN)
                last_e = time.time()
                hits = 0
            elapsed = self.time_elapsed_accounting_for_freeze(start)
            if elapsed - last_log >= self.GATE_LOG_EVERY:
                last_log = elapsed
                self.logger.warning(f'yangyang: enhanced heavy still not lit after '
                                    f'{elapsed:.1f}s (white={white:.4f}, recasts={recasts})')
            self.sleep(self.E_RELIGHT_POLL)

        if recasts:
            self.logger.info(f'yangyang: enhanced heavy lit after {recasts} recast(s), '
                             f'{self.time_elapsed_accounting_for_freeze(start):.1f}s')
        self.hold_for_damage('E后强化重击', self.HEAVY1_TO_DAMAGE)
        self.logger.info(f'yangyang: E->R total '
                         f'{self.time_elapsed_accounting_for_freeze(e_cast):.1f}s')

    def cast_liberation(self, e_cast):
        """按 E 之后过 E_TO_LIB 秒放 R。图标没亮就再多等 —— 手不松, 一直在打。

        进来先把三个状态打进日志, 分清失败原因:
          has_cd=True            → 真在冷却
          lib_avail/has_cd 都 False → 能量没满 (或图标被后摇/特效压暗)
          flying=True            → 人在空中, 这时候读图标和放大招都不靠谱
        click_liberation() 是阻塞到大招演出结束才返回的, 所以它返回之后不用再等动画。
        """
        # 【必须打到】E 之后手不松, 打到强化重击亮起、再打完它, 然后才准放 R。
        # 原来这里是死等 E_TO_LIB=5.85 秒 —— 那 5.85 秒被打断的话重击根本没出来,
        # 照样按 R, 于是"爆炸出伤"那一下的收益整个丢掉
        self.hold_through_enhanced_heavy(e_cast)
        self.logger.info(f'yangyang: pre-R lib_avail={self.liberation_available()} '
                         f'has_cd={self.has_cd("liberation")} flying={self.flying()}')

        # 到点了图标还没亮就再宽限一会儿, 这段是超出 E_TO_LIB 的额外时间
        start = time.time()
        while not self.liberation_available() \
                and self.time_elapsed_accounting_for_freeze(start) < self.LIB_MAX_WAIT:
            self.sleep(self.HOLD_POLL)
        extra = self.time_elapsed_accounting_for_freeze(start)
        if extra > 0.1:
            self.logger.info(f'yangyang: +{extra:.1f}s extra waiting for liberation icon '
                             f'(E->R total {self.E_TO_LIB + extra:.1f}s)')
        return self.click_liberation(send_click=False, wait_if_cd_ready=self.LIB_WAIT)

    def drain_forte(self):
        """长按普攻打空能量条, 等 E 图标亮起来就按 E。

        判定走的是 E 图标框里的白像素占比 (E_LIT_THRESHOLD), 不是找图。
        走到这一步之前排除掉的两条路, 记一下省得再试:
          - resonance_available() 是 available('resonance', check_color=False), 只查 CD
            不查高亮。秧秧进场 E 本来就不在 CD, 判定 0.0s 就返回 (21:47:58 那条日志);
          - is_e_forte_full() → task.find_e_forte() 匹配的是通用模板 e_forte, 玄翎的
            强化E 图标对不上, 一路超时 (21:53:43 那条)。
        A_DRAIN_TIME 只是判定失灵时的上限兜底。
        """
        start = time.time()
        last_probe = -1.0
        peak = 0.0
        first_lit = -1.0
        lit_hits = 0
        while self.time_elapsed_accounting_for_freeze(start) < self.A_DRAIN_TIME:
            elapsed = self.time_elapsed_accounting_for_freeze(start)

            # 一次采样同时供打印和判定用, 别读两遍
            if elapsed - last_probe >= self.E_LIT_PROBE_INTERVAL:
                last_probe = elapsed
                white = self.e_icon_white()
                if self.E_LIT_PROBE:
                    self.probe_e_icon(elapsed, white)
                if white > peak:
                    peak = white
                if first_lit < 0 and white >= self.E_LIT_EDGE:
                    first_lit = elapsed

                if self.E_LIT_THRESHOLD > 0:
                    lit_hits = lit_hits + 1 if white >= self.E_LIT_THRESHOLD else 0
                    if elapsed >= self.MIN_FORTE_DRAIN and lit_hits >= self.E_LIT_CONFIRM:
                        self.logger.info(f'yangyang: e icon lit at {elapsed:.2f}s '
                                         f'(white={white:.4f}), casting E')
                        return True

            if self.E_FORTE_DETECT and elapsed >= self.MIN_FORTE_DRAIN and self.is_e_forte_full():
                self.logger.info(f'yangyang: e forte template hit at {elapsed:.2f}s')
                return True

            self.sleep(self.E_LIT_POLL)
        self.logger.info(f'yangyang: A hit the {self.A_DRAIN_TIME:.1f}s cap without e lit '
                         f'(peak={peak:.4f} first_lit_at={first_lit:.2f}s), casting E anyway')
        return False

    def final_e_heavy(self):
        """R 之后的强化E + 第二个强化重击, 打完【并且出伤】才准切穗穗。

        实机确认的流程: 「R 以后 E 也会高亮，直接亮了按 E，再接一个强化重击
        (这个也要等一下，出伤了再切穗穗)」。

        判据换掉了。原来用 has_cd('resonance') 确认这一下 E 有没有进去, 实测
        7/7 全判失败 —— 强化段很可能是消耗强化态而不进基础冷却, 那这个判据永远为假,
        而旧代码判失败就 mouse_up() 松手, 整条轴的最后一个重击 100% 丢掉。
        现在改成看【强化重击标记亮没亮】: 标记亮起来就证明 E 进去了。它既是硬判据,
        又正好是我们真正关心的那个东西。E 图标亮度那条路也不用了 —— 这一步实测
        9 次采样峰值全是 0.12, 阈值 0.13, 一次都没过。

        顺序仍然是 按E → 立刻按住 → 再确认: 重击从"按住"派生, 隔久了窗口就过了。
        """
        self.send_resonance_key(down_time=self.E_KEY_DOWN)
        self.sleep(self.E_TO_HEAVY, check_combat=False)
        self.task.mouse_down()  # 按住接重击
        try:
            # 标记亮起来 = E 真的进去了。没亮就在按住的状态下补按 —— pre 挡住冷却里的空按
            self.require_cast('R后强化E',
                              send=lambda: self.send_resonance_key(down_time=self.E_KEY_DOWN),
                              landed=self.is_mouse_forte_full,
                              pre=self.resonance_available)
            self.hold_for_damage('R后强化重击', self.HEAVY2_TO_DAMAGE)
        finally:
            self.task.mouse_up()
        return True

    def cast_e_confirmed(self):
        """按 E, 并确认它真的放出去了; 被吃掉就重按。

        走框架的 click_resonance(): 它一直重按到共鸣技能进冷却为止, 这是唯一硬的判据。
        返回【第一次】按 E 的时间戳: E_TO_LIB 从那一刻起算, 重按的耗时算在里面,
        否则每补一次 R 就往后推一次。
        """
        first = time.time()
        self.logger.info('yangyang: E cast, holding attack through the animation')
        if not self.E_CAST_CONFIRM:
            self.send_resonance_key(down_time=self.E_KEY_DOWN)
            return first

        # send_click=False: 鼠标本来就按着, 别让框架再往里插普攻点击把长按打断
        clicked, duration, _ = self.click_resonance(send_click=False,
                                                    time_out=self.E_CAST_TIMEOUT)
        if clicked:
            self.logger.info(f'yangyang: E confirmed on cd after {duration:.2f}s')
        else:
            self.logger.warning('yangyang: click_resonance never registered, sending key blind')
            self.send_resonance_key(down_time=self.E_KEY_DOWN)
        return first

    def e_icon_white(self):
        """E 技能图标框里的白像素占比。读不到时返回 -1, 不让它把轴卡住。"""
        try:
            box = self.task.get_box_by_name(self.E_LIT_BOX)
            return self.task.calculate_color_percentage(self.E_LIT_COLOR, box)
        except Exception as e:
            self.logger.info(f'yangyang: e icon probe failed ({e})')
            return -1

    def probe_e_icon(self, elapsed, white=None):
        """把 E 图标的两种读数打进日志, 用来定 E_LIT_THRESHOLD。

        占比在某一秒跳一档的那个位置就是"回路打空、E 变强化"的时刻,
        取跳变前后的中间值填给 E_LIT_THRESHOLD 即可。返回本次读数供调用方统计峰值。
        """
        if white is None:
            white = self.e_icon_white()
        msg = f'yangyang probe t={elapsed:.2f}s white={white:.4f}'
        if self.E_LIT_PROBE_TEMPLATE:
            try:
                msg += f' e_forte={bool(self.task.find_e_forte())}'
            except Exception:
                msg += ' e_forte=err'
        self.logger.info(msg)
        return white

    # ------------------------------------------------------------------ 旧路径 (本队不用)

    def do_legacy_perform(self):
        duration = self.INTRO_PERFORM_DURATION if self.has_intro else self.PERFORM_DURATION
        start = time.time()
        self.task.mouse_down()
        resonance_available = 0
        try:
            while self.time_elapsed_accounting_for_freeze(start) < duration:
                if self.liberation_available():
                    self.logger.debug('liberation_available')
                    if not self.click_liberation(send_click=False, wait_if_cd_ready=0):
                        pass
                    else:
                        duration += 2
                elif self.resonance_available():
                    self.logger.debug('resonance_available')
                    if resonance_available == 0:
                        resonance_available = time.time()
                    if resonance_available != 0 and time.time() - resonance_available > 0.2:
                        self.logger.debug('resonance available for 0.2')
                        self.click_resonance(send_click=False, time_out=1)
                else:
                    resonance_available = 0
                self.task.next_frame()
        finally:
            self.task.mouse_up()
        self.switch_next_char()